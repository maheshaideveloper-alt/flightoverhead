# FlightOverhead — Setup Guide

## 1. Set your home coordinates

Open `app/src/main/java/com/flightoverhead/data/FlightRepository.kt` and update:

```kotlin
const val HOME_LAT = 32.897   // ← your latitude
const val HOME_LON = -97.040  // ← your longitude
const val RADIUS_DEG = 0.5    // ← search radius (~35 miles). Shrink to 0.2 for ~15 miles
```

To find your coordinates: open Google Maps, right-click your home → the first line shown is lat, lon.

## 2. Open in Android Studio

Open the `FlightOverhead/` folder in Android Studio (File → Open).
Let Gradle sync finish.

## 3. Run

Connect your Android phone (USB debugging on) or use the emulator, then click ▶ Run.

## 4. Grant permissions

On first launch, approve:
- Location (optional, for future GPS centering)
- Notifications (required for overhead alerts)

## What it does

| Feature | Detail |
|---|---|
| Live map | OSMDroid (OpenStreetMap) — no API key needed |
| Data source | OpenSky Network — free, no key needed |
| Auto-refresh | Every 60 seconds while app is open |
| Background alerts | WorkManager fires every 15 min, notifies if flights are overhead |
| Tap a plane | Opens detail screen: altitude, speed, heading, vertical rate, squawk |
| FlightAware link | Tap "View on FlightAware →" in detail screen for full flight info |

## No API key required

OpenSky's anonymous tier allows ~100 requests/day. With 60s refresh that's
~1440 calls/day — to stay within limits, the app only polls when foregrounded.
The background worker fires every 15 min (96 calls/day), well within limits.

If you create a free OpenSky account you get 4000 calls/day.
Add credentials in `FlightRepository.kt` via OkHttp's `.authenticator {}`.
