package com.flightoverhead.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup

/**
 * Powerball / Mega Millions winning numbers + live jackpot estimate.
 *
 * There's no official free JSON API for jackpot amounts (state open-data
 * portals only publish winning numbers, not dollar figures), so this parses
 * lotteryusa.com's server-rendered result pages via well-defined CSS classes
 * (not fragile text regex). If that site's markup ever changes, [getResult]
 * just returns null for that game rather than crashing — callers should
 * treat a null as "unavailable right now" and keep showing the last value.
 */
object LotteryRepository {

    enum class Game(val path: String) {
        POWERBALL("powerball"),
        MEGA_MILLIONS("mega-millions")
    }

    data class LotteryResult(
        val numbers: List<Int>,   // 5 main numbers
        val bonusBall: Int,       // Powerball or Mega Ball
        val drawDate: String,     // e.g. "Wednesday, Jul 15, 2026"
        val jackpot: String       // e.g. "$526 Million"
    )

    private val client = OkHttpClient()

    suspend fun getResult(game: Game): LotteryResult? = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url("https://www.lotteryusa.com/${game.path}/")
                .header(
                    "User-Agent",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
                        "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
                )
                .build()
            val html = client.newCall(request).execute().use { it.body?.string() }
                ?: return@withContext null
            val doc = Jsoup.parse(html)

            // "Next est. jackpot" — the second .c-state-short-info__row (first is the
            // next-draw date). ownText() grabs just "$526 Million", skipping the
            // nested "Cash value: ..." span inside the same element.
            val jackpot = doc.select(".c-state-short-info__subtitle").firstOrNull()
                ?.ownText()?.trim()?.takeIf { it.isNotBlank() } ?: return@withContext null

            // First ball list on the page is the main draw (a second one for
            // "Double Play" follows for Powerball; Mega Millions has only one).
            val ballListEl = doc.select("ul.c-draw-card__ball-list").firstOrNull()
                ?: return@withContext null
            val balls = ballListEl.select("li.c-ball").mapNotNull { it.text().trim().toIntOrNull() }
            if (balls.size < 6) return@withContext null

            val dow = doc.select(".c-draw-card__draw-date-dow").firstOrNull()
                ?.text()?.trim()?.trimEnd(',') ?: ""
            val dateSub = doc.select(".c-draw-card__draw-date-sub").firstOrNull()
                ?.text()?.trim() ?: ""
            val drawDate = listOfNotNull(dow.takeIf { it.isNotBlank() }, dateSub.takeIf { it.isNotBlank() })
                .joinToString(", ")

            LotteryResult(
                numbers = balls.dropLast(1),
                bonusBall = balls.last(),
                drawDate = drawDate,
                jackpot = jackpot
            )
        } catch (e: Exception) {
            null
        }
    }
}
