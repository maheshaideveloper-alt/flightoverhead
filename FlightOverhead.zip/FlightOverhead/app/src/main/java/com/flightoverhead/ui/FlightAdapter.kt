package com.flightoverhead.ui

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup

import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.flightoverhead.R
import com.flightoverhead.data.Flight
import com.flightoverhead.databinding.ItemFlightBinding

class FlightAdapter(
    private val onFlightClick: (Flight) -> Unit
) : ListAdapter<Flight, FlightAdapter.FlightVH>(DIFF) {

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<Flight>() {
            override fun areItemsTheSame(a: Flight, b: Flight) = a.icao24 == b.icao24
            override fun areContentsTheSame(a: Flight, b: Flight) =
                a.altitudeFt == b.altitudeFt && a.speedKnots == b.speedKnots
        }
    }

    inner class FlightVH(private val b: ItemFlightBinding) : RecyclerView.ViewHolder(b.root) {

        fun bind(flight: Flight) {
            b.tvCallsign.text = flight.callsignClean
            b.tvCountry.text  = flight.originCountry.uppercase()
            b.tvAltitude.text = "${"%,d".format(flight.altitudeFt)} ft"
            b.tvSpeed.text    = "${flight.speedKnots} kts"
            b.tvHeading.text  = "${flight.heading.toInt()}° ${headingToCompass(flight.heading.toInt())}"

            // Status pill
            when (flight.climbDescr) {
                "Climbing" -> {
                    b.tvStatusPill.text = "▲ CLIMBING"
                    b.tvStatusPill.setBackgroundResource(R.drawable.bg_pill_climbing)
                    b.tvStatusPill.setTextColor(Color.parseColor("#4CAF7A"))
                }
                "Descending" -> {
                    b.tvStatusPill.text = "▼ DESCENDING"
                    b.tvStatusPill.setBackgroundResource(R.drawable.bg_pill_descending)
                    b.tvStatusPill.setTextColor(Color.parseColor("#F06060"))
                }
                else -> {
                    b.tvStatusPill.text = "— CRUISING"
                    b.tvStatusPill.setBackgroundResource(R.drawable.bg_pill_cruising)
                    b.tvStatusPill.setTextColor(Color.parseColor("#6EB3F0"))
                }
            }

            b.root.setOnClickListener { onFlightClick(flight) }
        }

        private fun headingToCompass(deg: Int): String {
            val dirs = arrayOf("N","NE","E","SE","S","SW","W","NW")
            return dirs[((deg + 22) / 45) % 8]
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FlightVH {
        val b = ItemFlightBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FlightVH(b)
    }

    override fun onBindViewHolder(holder: FlightVH, position: Int) {
        holder.bind(getItem(position))
        // Staggered fade-in animation
        holder.itemView.alpha = 0f
        holder.itemView.animate()
            .alpha(1f)
            .setStartDelay((position * 40L).coerceAtMost(400L))
            .setDuration(300)
            .start()
    }
}
