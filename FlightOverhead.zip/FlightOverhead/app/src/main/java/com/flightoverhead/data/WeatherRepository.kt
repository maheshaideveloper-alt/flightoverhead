package com.flightoverhead.data

import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

object WeatherRepository {

    private val client = OkHttpClient()

    /** Weather text plus the IANA timezone id (e.g. "America/Chicago") for the queried location. */
    data class WeatherInfo(val text: String, val timeZoneId: String?)

    /**
     * Fetches current weather AND the local IANA timezone for [lat]/[lon] in one call
     * (Open-Meteo resolves the timezone for any coordinate via `timezone=auto`).
     */
    suspend fun getWeatherInfo(
        lat: Double = FlightRepository.HOME_LAT,
        lon: Double = FlightRepository.HOME_LON
    ): WeatherInfo = withContext(Dispatchers.IO) {
        try {
            val url = "https://api.open-meteo.com/v1/forecast" +
                "?latitude=$lat" +
                "&longitude=$lon" +
                "&current_weather=true" +
                "&temperature_unit=fahrenheit" +
                "&windspeed_unit=mph" +
                "&timezone=auto"

            val request = Request.Builder().url(url).build()
            val body = client.newCall(request).execute().use { it.body?.string() }
                ?: return@withContext WeatherInfo("—", null)

            val root = JsonParser.parseString(body).asJsonObject
            val cw   = root.getAsJsonObject("current_weather")
            val temp = cw.get("temperature").asDouble.toInt()
            val tz   = root.get("timezone")?.takeIf { !it.isJsonNull }?.asString

            WeatherInfo("${temp}°F", tz)
        } catch (e: Exception) {
            WeatherInfo("Weather unavailable", null)
        }
    }
}
