package com.flightoverhead.data

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object FlightRepository {

    // ── Home coordinates ──────────────────────────────────────────────────
    const val HOME_LAT = 33.0060  // 33°00'21.7"N
    const val HOME_LON = -96.8453 // 96°50'43.1"W

    /** Adjustable search radius in degrees. 0.1 ≈ 7 mi, 1.0 ≈ 70 mi */
    var RADIUS_DEG = 0.5
        set(value) { field = value.coerceIn(0.1, 2.0) }

    /** Radius in miles (approx) */
    val radiusMiles: Int get() = (RADIUS_DEG * 69.0).toInt()
    // ──────────────────────────────────────────────────────────────────────

    private val api: OpenSkyApi by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()

        Retrofit.Builder()
            .baseUrl("https://opensky-network.org/api/")
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(OpenSkyApi::class.java)
    }

    /** Fetch all flights within RADIUS_DEG of home. Filters out on-ground aircraft. */
    suspend fun getFlightsOverhead(): List<Flight> {
        val response = api.getStates(
            latMin = HOME_LAT - RADIUS_DEG,
            lonMin = HOME_LON - RADIUS_DEG,
            latMax = HOME_LAT + RADIUS_DEG,
            lonMax = HOME_LON + RADIUS_DEG
        )
        return response.states
            ?.mapNotNull { it.toFlight() }
            ?.filter { !it.onGround }
            ?: emptyList()
    }
}
