package com.flightoverhead.ui

import android.text.TextUtils
import android.widget.TextView

/**
 * Marks a TextView as "marquee-ready": text that's longer than the view's
 * allocated width scrolls horizontally within that exact space instead of
 * wrapping, getting clipped, or spilling into neighboring UI.
 *
 * Call this once after the view is bound/inflated (and again is harmless —
 * it's idempotent). The XML counterpart (singleLine + ellipsize="marquee")
 * must also be set on the view; this function supplies the one piece that
 * can only be done in code: marking the view "selected", which is what
 * starts the marquee animation.
 *
 * Deliberately does NOT set focusable/focusableInTouchMode — those aren't
 * needed to trigger the marquee (setSelected(true) does that on its own),
 * and setting them on a TextView inside a clickable row (ListView item,
 * RecyclerView item, dialog button, etc.) steals touch/focus from the row
 * and breaks tap-to-select.
 */
fun TextView.enableMarquee() {
    isSingleLine = true
    ellipsize = TextUtils.TruncateAt.MARQUEE
    marqueeRepeatLimit = -1 // forever
    isSelected = true
}
