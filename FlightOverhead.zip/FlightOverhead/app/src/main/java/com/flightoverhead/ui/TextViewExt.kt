package com.flightoverhead.ui

import android.text.TextUtils
import android.widget.TextView

/**
 * Marks a TextView as "marquee-ready": text that's longer than the view's
 * allocated width scrolls horizontally within that exact space instead of
 * wrapping, getting clipped, or spilling into neighboring UI.
 *
 * Call this once after the view is bound/inflated (and again is harmless —
 * it's idempotent). The XML counterpart (singleLine + ellipsize="marquee" +
 * focusable) must also be set on the view; this function supplies the one
 * piece that can only be done in code: marking the view "selected", which is
 * what actually starts the marquee animation on a non-focused, non-list-item
 * TextView.
 */
fun TextView.enableMarquee() {
    isSingleLine = true
    ellipsize = TextUtils.TruncateAt.MARQUEE
    marqueeRepeatLimit = -1 // forever
    isFocusable = true
    isFocusableInTouchMode = true
    isSelected = true
}
