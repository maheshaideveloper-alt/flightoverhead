package com.flightoverhead.ui

import android.content.Context
import android.util.AttributeSet
import android.widget.VideoView

/**
 * A VideoView that stretches to fill its parent completely,
 * ignoring the video's native aspect ratio.
 */
class FillVideoView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : VideoView(context, attrs, defStyle) {

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width  = MeasureSpec.getSize(widthMeasureSpec)
        val height = MeasureSpec.getSize(heightMeasureSpec)
        setMeasuredDimension(width, height)
    }
}
