package com.flightoverhead.ui

import android.content.Context
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.net.Uri
import android.util.AttributeSet
import android.view.Surface
import android.view.TextureView

/**
 * TextureView-based video player that:
 * - Fills its container completely (no letterbox) — the video is center-cropped
 *   ("zoom to fill") to preserve its aspect ratio rather than stretched.
 * - Participates in View alpha animations (unlike SurfaceView/VideoView)
 *   so fade-in/out works perfectly in sync with other views.
 */
class FillVideoView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : TextureView(context, attrs), TextureView.SurfaceTextureListener {

    private var mediaPlayer: MediaPlayer? = null
    private var videoUri: Uri? = null
    private var surfaceReady = false
    private var videoW = 0
    private var videoH = 0

    var onFirstFrameReady: (() -> Unit)? = null

    /** When false, playback stops after a single pass and [onCompletion] fires. */
    var isLoopPlayback: Boolean = true
        set(value) {
            field = value
            mediaPlayer?.isLooping = value
        }

    /** Fires when a non-looping ([isLoopPlayback] = false) playback reaches the end. */
    var onCompletion: (() -> Unit)? = null

    init {
        surfaceTextureListener = this
        isOpaque = false
    }

    fun setVideoURI(uri: Uri) {
        videoUri = uri
        if (surfaceReady) setupMediaPlayer()
    }

    private fun setupMediaPlayer() {
        val uri = videoUri ?: return
        mediaPlayer?.release()
        try {
            val mp = MediaPlayer().apply {
                setDataSource(context, uri)
                setSurface(Surface(surfaceTexture))
                setVolume(0f, 0f)
                isLooping = isLoopPlayback
                setOnPreparedListener { it.start() }
                setOnCompletionListener { post { onCompletion?.invoke() } }
                setOnVideoSizeChangedListener { _, w, h ->
                    videoW = w; videoH = h
                    post { updateTransform() }
                }
                setOnInfoListener { _, what, _ ->
                    if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) {
                        post { onFirstFrameReady?.invoke() }
                    }
                    false
                }
                prepareAsync()
            }
            mediaPlayer = mp
        } catch (e: Exception) { e.printStackTrace() }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        // The view itself always spans its full container; aspect ratio is
        // preserved separately via a center-crop transform in updateTransform().
        setMeasuredDimension(
            MeasureSpec.getSize(widthMeasureSpec),
            MeasureSpec.getSize(heightMeasureSpec)
        )
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        updateTransform()
    }

    /**
     * Center-crop ("zoom to fill"): scales the video's rendered content so it
     * fully covers the view bounds while preserving aspect ratio, cropping
     * whatever overflows top/bottom or left/right — instead of the default
     * TextureView behavior of stretching non-uniformly to fill exactly.
     */
    private fun updateTransform() {
        if (videoW <= 0 || videoH <= 0 || width <= 0 || height <= 0) return
        val viewRatio  = width.toFloat() / height.toFloat()
        val videoRatio = videoW.toFloat() / videoH.toFloat()
        var scaleX = 1f
        var scaleY = 1f
        if (videoRatio > viewRatio) {
            // Video is relatively wider than the view — grow X to crop the sides.
            scaleX = videoRatio / viewRatio
        } else {
            // Video is relatively taller than the view — grow Y to crop top/bottom.
            scaleY = viewRatio / videoRatio
        }
        val matrix = Matrix()
        matrix.setScale(scaleX, scaleY, width / 2f, height / 2f)
        setTransform(matrix)
    }

    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
        surfaceReady = true
        if (videoUri != null) setupMediaPlayer()
    }

    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {
        updateTransform()
    }

    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
        mediaPlayer?.release(); mediaPlayer = null; surfaceReady = false
        videoW = 0; videoH = 0
        return true
    }

    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}

    val isPlaying get() = mediaPlayer?.isPlaying == true
    fun pause()  { mediaPlayer?.pause() }
    fun resume() { mediaPlayer?.start() }
    fun seekAndPlay() { mediaPlayer?.seekTo(0); mediaPlayer?.start() }
    fun stopPlayback() { mediaPlayer?.release(); mediaPlayer = null }
}
