package com.flightoverhead.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.View

/**
 * Draws a compass rose — N/E/S/W labels plus a two-tone needle — as a single
 * unit. The view itself is drawn "north-up" (N at the top); the caller rotates
 * the whole thing via [View.setRotation] to reflect the current heading, which
 * keeps the needle and the four labels turning together and staying honest
 * about which screen-direction is actually north/east/south/west.
 */
class CompassRoseView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private val northPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#FF3B30")
    }
    private val southPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#D6E4EC")
    }
    private val pivotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#0D1526")
    }
    private val labelPaintN = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#FF3B30")
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#38BDF8")
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }

    private val needlePath = Path()

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r  = minOf(width, height) / 2f

        val labelSize = r * 0.34f
        labelPaintN.textSize = labelSize
        labelPaint.textSize  = labelSize
        val labelInset = r * 0.86f
        val textOffset = labelSize * 0.36f // vertical centering fudge for drawText baseline

        // Cardinal labels
        canvas.drawText("N", cx, cy - labelInset + labelSize - textOffset, labelPaintN)
        canvas.drawText("S", cx, cy + labelInset - textOffset, labelPaint)
        canvas.drawText("E", cx + labelInset, cy + textOffset, labelPaint)
        canvas.drawText("W", cx - labelInset, cy + textOffset, labelPaint)

        // Needle — sized to leave clear room for the labels around it
        val needleLen = r * 0.52f
        val needleWidth = needleLen * 0.42f

        needlePath.reset()
        needlePath.moveTo(cx, cy - needleLen)
        needlePath.lineTo(cx + needleWidth, cy)
        needlePath.lineTo(cx, cy - needleLen * 0.12f)
        needlePath.lineTo(cx - needleWidth, cy)
        needlePath.close()
        canvas.drawPath(needlePath, northPaint)

        needlePath.reset()
        needlePath.moveTo(cx, cy + needleLen)
        needlePath.lineTo(cx + needleWidth, cy)
        needlePath.lineTo(cx, cy + needleLen * 0.12f)
        needlePath.lineTo(cx - needleWidth, cy)
        needlePath.close()
        canvas.drawPath(needlePath, southPaint)

        canvas.drawCircle(cx, cy, r * 0.12f, pivotPaint)
    }
}
