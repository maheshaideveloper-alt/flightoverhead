package com.flightoverhead

import android.Manifest
import android.animation.ValueAnimator
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.work.*
import com.flightoverhead.data.Flight
import com.flightoverhead.data.FlightRepository
import com.flightoverhead.data.WeatherRepository
import com.flightoverhead.databinding.ActivityMainBinding
import com.flightoverhead.service.FlightMonitorWorker
import com.flightoverhead.ui.FlightAdapter
import com.flightoverhead.ui.FlightInfoWindow
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Overlay
import org.osmdroid.views.overlay.infowindow.InfoWindow
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: FlightAdapter

    private val homePoint = GeoPoint(FlightRepository.HOME_LAT, FlightRepository.HOME_LON)
    private val flightMarkers = mutableMapOf<String, Marker>()

    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val dateFmt = SimpleDateFormat("EEEE, MMMM d", Locale.US)

    // Pulsing blue dot
    private var pulseRadius = 30f
    private lateinit var pulseAnimator: ValueAnimator

    private val darkTileSource = XYTileSource(
        "CartoDarkMatter", 0, 19, 256, ".png",
        arrayOf(
            "https://a.basemaps.cartocdn.com/dark_all/",
            "https://b.basemaps.cartocdn.com/dark_all/",
            "https://c.basemaps.cartocdn.com/dark_all/"
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // True full-screen immersive
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )

        Configuration.getInstance().userAgentValue = packageName
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupMap()
        setupPulseAnimation()
        setupClickListeners()
        requestPermissions()
        startAutoRefresh()
        startClockTick()
        scheduleBackgroundMonitor()

        // Static HUD values
        binding.tvMapCoords.text =
            "%.4f° N   %.4f° W".format(FlightRepository.HOME_LAT, Math.abs(FlightRepository.HOME_LON))
    }

    // ── Pulse animation (blue dot) ───────────────────────────────────────

    private fun setupPulseAnimation() {
        pulseAnimator = ValueAnimator.ofFloat(18f, 65f).apply {
            duration = 1800
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.RESTART
            interpolator = LinearInterpolator()
            addUpdateListener {
                pulseRadius = it.animatedValue as Float
                binding.map.invalidate()
            }
            start()
        }
    }

    // ── RecyclerView ─────────────────────────────────────────────────────

    private fun setupRecyclerView() {
        // Tap centres the map on that flight
        adapter = FlightAdapter { flight ->
            binding.map.controller.animateTo(GeoPoint(flight.latitude, flight.longitude))
        }
        binding.rvFlights.layoutManager = LinearLayoutManager(this)
        binding.rvFlights.adapter = adapter
        binding.rvFlights.itemAnimator = null
    }

    // ── Map ──────────────────────────────────────────────────────────────

    private fun setupMap() {
        binding.map.apply {
            setTileSource(darkTileSource)
            setMultiTouchControls(true)
            controller.setZoom(9.5)
            controller.setCenter(homePoint)
            isTilesScaledToDpi = true
        }
        addRadiusCircle()
        addBlueDotOverlay()   // home as pulsing blue dot
    }

    private fun addBlueDotOverlay() {
        binding.map.overlays.add(object : Overlay() {
            private val pulsePaint = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL }
            private val dotPaint   = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL; color = Color.rgb(66, 133, 244) }
            private val ringPaint  = Paint().apply { isAntiAlias = true; style = Paint.Style.STROKE; strokeWidth = 3f; color = Color.WHITE }
            private val shadowPaint = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL; color = Color.argb(60, 0, 0, 0) }

            override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
                if (shadow) return
                val proj = mapView.projection
                val center = proj.toPixels(homePoint, null)
                val cx = center.x.toFloat()
                val cy = center.y.toFloat()

                // Fading pulse ring
                val fraction = (pulseRadius - 18f) / 47f          // 0 → 1
                val alpha = (255 * (1f - fraction) * 0.5f).toInt().coerceIn(0, 128)
                pulsePaint.color = Color.argb(alpha, 66, 133, 244)
                canvas.drawCircle(cx, cy, pulseRadius, pulsePaint)

                // Drop shadow
                canvas.drawCircle(cx, cy + 2f, 13f, shadowPaint)
                // Blue dot
                canvas.drawCircle(cx, cy, 12f, dotPaint)
                // White ring
                canvas.drawCircle(cx, cy, 12f, ringPaint)
            }
        })
    }

    private fun addRadiusCircle() {
        val rad = FlightRepository.RADIUS_DEG
        binding.map.overlays.add(object : Overlay() {
            private val fill   = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL;   color = Color.argb(18, 201, 168, 76) }
            private val stroke = Paint().apply { isAntiAlias = true; style = Paint.Style.STROKE; color = Color.argb(90, 201, 168, 76); strokeWidth = 2f }
            override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
                if (shadow) return
                val proj   = mapView.projection
                val center = proj.toPixels(homePoint, null)
                val edge   = proj.toPixels(GeoPoint(homePoint.latitude + rad, homePoint.longitude), null)
                val r      = Math.abs(center.y - edge.y).toFloat()
                val cx = center.x.toFloat(); val cy = center.y.toFloat()
                canvas.drawCircle(cx, cy, r, fill)
                canvas.drawCircle(cx, cy, r, stroke)
            }
        })
    }

    // ── Auto-refresh ──────────────────────────────────────────────────────

    private fun startAutoRefresh() {
        lifecycleScope.launch {
            while (isActive) {
                loadFlights()
                loadWeather()
                delay(60_000)
            }
        }
    }

    private fun startClockTick() {
        lifecycleScope.launch {
            while (isActive) {
                val now = Date()
                binding.tvMapTime.text = timeFmt.format(now)
                binding.tvMapDate.text = dateFmt.format(now).uppercase()
                delay(1_000)
            }
        }
    }

    private suspend fun loadFlights() {
        showLoading(true)
        try {
            val flights = FlightRepository.getFlightsOverhead().sortedByDescending { it.altitudeFt }
            updateList(flights)
            updateMap(flights)
            binding.tvFlightCount.text = "${flights.size} flights overhead"
            binding.tvLastUpdated.text = "  Updated ${timeFmt.format(Date())}"
        } catch (e: Exception) {
            binding.tvLastUpdated.text = "  Error fetching data"
        } finally {
            showLoading(false)
        }
    }

    private suspend fun loadWeather() {
        binding.tvWeather.text = WeatherRepository.getWeatherString()
    }

    private fun showLoading(loading: Boolean) {
        if (loading && adapter.currentList.isEmpty()) {
            binding.loadingContainer.visibility = View.VISIBLE
            binding.rvFlights.visibility = View.GONE
            binding.emptyState.visibility = View.GONE
        } else {
            binding.loadingContainer.visibility = View.GONE
        }
    }

    private fun updateList(flights: List<Flight>) {
        if (flights.isEmpty()) {
            binding.emptyState.visibility = View.VISIBLE
            binding.rvFlights.visibility = View.GONE
        } else {
            binding.emptyState.visibility = View.GONE
            binding.rvFlights.visibility = View.VISIBLE
        }
        adapter.submitList(flights)
    }

    private fun updateMap(flights: List<Flight>) {
        val currentIcao = flights.map { it.icao24 }.toSet()
        flightMarkers.keys.filter { it !in currentIcao }.forEach { icao ->
            binding.map.overlays.remove(flightMarkers[icao])
            flightMarkers.remove(icao)
        }
        for (flight in flights) {
            val pos = GeoPoint(flight.latitude, flight.longitude)
            val existing = flightMarkers[flight.icao24]
            if (existing != null) {
                existing.position = pos
                existing.title    = flight.callsignClean
                existing.snippet  = "${"%,d".format(flight.altitudeFt)} ft · ${flight.speedKnots} kts · ${flight.climbDescr}"
                existing.rotation = flight.heading.toFloat()
            } else {
                val marker = Marker(binding.map).apply {
                    position   = pos
                    title      = flight.callsignClean
                    icon       = ContextCompat.getDrawable(this@MainActivity, R.drawable.ic_plane_gold)
                    rotation   = flight.heading.toFloat()
                    infoWindow = FlightInfoWindow(flight, binding.map)
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                    setOnMarkerClickListener { m, _ ->
                        InfoWindow.closeAllInfoWindowsOn(binding.map)
                        m.showInfoWindow()
                        true
                    }
                }
                binding.map.overlays.add(marker)
                flightMarkers[flight.icao24] = marker
            }
        }
        binding.map.invalidate()
    }

    // ── Click listeners ────────────────────────────────────────────────────

    private fun setupClickListeners() {
        binding.btnRefresh.setOnClickListener {
            it.animate().rotation(it.rotation + 360f).setDuration(500).start()
            lifecycleScope.launch {
                loadFlights()
                loadWeather()
            }
        }
    }

    // ── Background monitor ────────────────────────────────────────────────

    private fun scheduleBackgroundMonitor() {
        val req = PeriodicWorkRequestBuilder<FlightMonitorWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            FlightMonitorWorker.WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, req
        )
    }

    // ── Permissions ───────────────────────────────────────────────────────

    private fun requestPermissions() {
        val perms = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.POST_NOTIFICATIONS)
        val missing = perms.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 1)
    }

    override fun onResume()  { super.onResume(); binding.map.onResume() }
    override fun onPause()   { super.onPause();  binding.map.onPause()  }
    override fun onDestroy() { super.onDestroy(); if (::pulseAnimator.isInitialized) pulseAnimator.cancel() }
}
