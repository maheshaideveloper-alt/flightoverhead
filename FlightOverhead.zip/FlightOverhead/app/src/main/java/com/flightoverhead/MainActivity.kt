package com.flightoverhead

import android.Manifest
import android.animation.ValueAnimator
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.work.*
import com.flightoverhead.data.Flight
import com.flightoverhead.data.FlightRepository
import com.flightoverhead.data.WeatherRepository
import com.flightoverhead.databinding.ActivityMainBinding
import com.flightoverhead.service.FlightMonitorWorker
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Overlay
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val homePoint = GeoPoint(FlightRepository.HOME_LAT, FlightRepository.HOME_LON)
    private val flightData = mutableMapOf<String, Flight>()

    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val dateFmt = SimpleDateFormat("MMMM d, yyyy", Locale.US)
    private val dayFmt  = SimpleDateFormat("EEEE", Locale.US)

    private var pulseRadius = 30f
    private lateinit var pulseAnimator: ValueAnimator

    private var radiusOverlay: Overlay? = null
    private var selectedIcao: String? = null
    private lateinit var chipOverlay: FlightChipOverlay

    private val darkTiles = XYTileSource(
        "CartoDarkMatter", 0, 19, 256, ".png",
        arrayOf(
            "https://a.basemaps.cartocdn.com/dark_all/",
            "https://b.basemaps.cartocdn.com/dark_all/",
            "https://c.basemaps.cartocdn.com/dark_all/"
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )

        Configuration.getInstance().userAgentValue = packageName
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupMap()
        setupPulseAnimation()
        setupRadiusSlider()
        setupClickListeners()
        requestPermissions()
        startAutoRefresh()
        startClockTick()
        scheduleBackgroundMonitor()

        binding.tvMapCoords.text =
            "%.4f° N  %.4f° W".format(FlightRepository.HOME_LAT, Math.abs(FlightRepository.HOME_LON))
    }

    // ── Pulse animation ───────────────────────────────────────────────────

    private fun setupPulseAnimation() {
        pulseAnimator = ValueAnimator.ofFloat(16f, 60f).apply {
            duration = 1800; repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.RESTART
            addUpdateListener { pulseRadius = it.animatedValue as Float; binding.map.invalidate() }
            start()
        }
    }

    // ── Map ───────────────────────────────────────────────────────────────

    private fun setupMap() {
        binding.map.apply {
            setTileSource(darkTiles)
            setMultiTouchControls(true)
            controller.setZoom(9.5)
            controller.setCenter(homePoint)
            isTilesScaledToDpi = true
        }
        addRadiusCircle()
        addBlueDotOverlay()
        chipOverlay = FlightChipOverlay()
        binding.map.overlays.add(chipOverlay)
    }

    private fun addBlueDotOverlay() {
        val dotPaint    = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL; color = Color.rgb(66, 133, 244) }
        val ringPaint   = Paint().apply { isAntiAlias = true; style = Paint.Style.STROKE; strokeWidth = 3f; color = Color.WHITE }
        val shadowPaint = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL; color = Color.argb(50, 0, 0, 0) }
        val pulsePaint  = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL }
        binding.map.overlays.add(object : Overlay() {
            override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
                if (shadow) return
                val c = mapView.projection.toPixels(homePoint, null)
                val cx = c.x.toFloat(); val cy = c.y.toFloat()
                val frac = (pulseRadius - 16f) / 44f
                pulsePaint.color = Color.argb(((1f - frac) * 120f).toInt().coerceIn(0, 120), 66, 133, 244)
                canvas.drawCircle(cx, cy, pulseRadius, pulsePaint)
                canvas.drawCircle(cx, cy + 2f, 13f, shadowPaint)
                canvas.drawCircle(cx, cy, 12f, dotPaint)
                canvas.drawCircle(cx, cy, 12f, ringPaint)
            }
        })
    }

    private fun addRadiusCircle() {
        radiusOverlay?.let { binding.map.overlays.remove(it) }
        val rad    = FlightRepository.RADIUS_DEG
        val fill   = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL; color = Color.argb(18, 201, 168, 76) }
        val stroke = Paint().apply { isAntiAlias = true; style = Paint.Style.STROKE; color = Color.argb(90, 201, 168, 76); strokeWidth = 2f }
        val ov = object : Overlay() {
            override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
                if (shadow) return
                val proj = mapView.projection
                val c = proj.toPixels(homePoint, null)
                val e = proj.toPixels(GeoPoint(homePoint.latitude + rad, homePoint.longitude), null)
                val r = Math.abs(c.y - e.y).toFloat()
                canvas.drawCircle(c.x.toFloat(), c.y.toFloat(), r, fill)
                canvas.drawCircle(c.x.toFloat(), c.y.toFloat(), r, stroke)
            }
        }
        binding.map.overlays.add(ov)
        radiusOverlay = ov
        binding.map.invalidate()
    }

    // ── Flight chip overlay ───────────────────────────────────────────────
    //
    // Each flight is drawn as:
    //   • A top-down airplane silhouette (fuselage + swept wings + tail fins)
    //     rotated to the flight's heading
    //   • A small gold label chip below it with the callsign
    //
    // Tapping a chip toggles its selection (gold highlight). No detail screen.

    private inner class FlightChipOverlay : Overlay() {

        private var flights: List<Flight> = emptyList()
        private val hitAreas = ArrayList<Pair<RectF, Flight>>(32)

        // Label chip paints
        private val bgPaint   = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val bordPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val txtPaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            color    = Color.parseColor("#E8D5A3")
        }

        // Plane silhouette paints + path (reused each frame)
        private val planePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val planePath  = Path()

        fun setFlights(list: List<Flight>) { flights = list }

        override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
            if (shadow) return
            hitAreas.clear()
            for (flight in flights) {
                val pt = mapView.projection.toPixels(
                    GeoPoint(flight.latitude, flight.longitude), null)
                drawFlight(canvas, pt.x.toFloat(), pt.y.toFloat(), flight)
            }
        }

        private fun drawFlight(canvas: Canvas, cx: Float, cy: Float, flight: Flight) {
            val selected  = flight.icao24 == selectedIcao
            val goldColor = if (selected) Color.parseColor("#FFD700") else Color.parseColor("#C9A84C")
            val bgColor   = if (selected) Color.argb(245, 35, 22, 0) else Color.argb(200, 7, 11, 20)

            // ── Airplane silhouette ────────────────────────────────────────
            planePaint.color = goldColor
            canvas.save()
            canvas.rotate(flight.heading.toFloat(), cx, cy)

            val s = 14f   // scale unit

            // Fuselage — nose points up (−Y), tail down (+Y)
            planePath.reset()
            planePath.moveTo(cx,              cy - s * 2.0f)   // nose
            planePath.lineTo(cx + s * 0.22f,  cy - s * 0.8f)
            planePath.lineTo(cx + s * 0.22f,  cy + s * 1.3f)
            planePath.lineTo(cx,              cy + s * 1.6f)   // tail tip
            planePath.lineTo(cx - s * 0.22f,  cy + s * 1.3f)
            planePath.lineTo(cx - s * 0.22f,  cy - s * 0.8f)
            planePath.close()
            canvas.drawPath(planePath, planePaint)

            // Main wings — swept back
            planePath.reset()
            planePath.moveTo(cx,              cy - s * 0.4f)   // leading edge root
            planePath.lineTo(cx + s * 2.0f,   cy + s * 0.7f)  // right wingtip leading
            planePath.lineTo(cx + s * 1.6f,   cy + s * 1.0f)  // right wingtip trailing
            planePath.lineTo(cx + s * 0.2f,   cy + s * 0.5f)  // trailing edge root right
            planePath.lineTo(cx - s * 0.2f,   cy + s * 0.5f)  // trailing edge root left
            planePath.lineTo(cx - s * 1.6f,   cy + s * 1.0f)  // left wingtip trailing
            planePath.lineTo(cx - s * 2.0f,   cy + s * 0.7f)  // left wingtip leading
            planePath.close()
            canvas.drawPath(planePath, planePaint)

            // Tail stabilisers — small swept fins near tail
            planePath.reset()
            planePath.moveTo(cx,              cy + s * 1.0f)   // root
            planePath.lineTo(cx + s * 0.9f,   cy + s * 1.5f)  // right tip
            planePath.lineTo(cx + s * 0.2f,   cy + s * 1.6f)
            planePath.lineTo(cx - s * 0.2f,   cy + s * 1.6f)
            planePath.lineTo(cx - s * 0.9f,   cy + s * 1.5f)  // left tip
            planePath.close()
            canvas.drawPath(planePath, planePaint)

            canvas.restore()

            // ── Callsign chip below the plane ─────────────────────────────
            val label = flight.callsignClean
            val tw    = txtPaint.measureText(label)
            val pH = 12f; val pV = 6f
            val chipW = tw + pH * 2
            val chipH = txtPaint.textSize + pV * 2

            val left = cx - chipW / 2f
            val top  = cy + s * 2.0f + 4f
            val rect = RectF(left, top, left + chipW, top + chipH)

            bgPaint.color         = bgColor
            bordPaint.color       = goldColor
            bordPaint.strokeWidth = if (selected) 2.5f else 1.5f

            canvas.drawRoundRect(rect, 7f, 7f, bgPaint)
            canvas.drawRoundRect(rect, 7f, 7f, bordPaint)
            canvas.drawText(label, left + pH, top + pV + txtPaint.textSize * 0.85f, txtPaint)

            // Hit area covers both plane + chip
            hitAreas.add(Pair(
                RectF(cx - s * 2.1f, cy - s * 2.1f, cx + s * 2.1f, top + chipH),
                flight
            ))
        }

        override fun onSingleTapConfirmed(e: MotionEvent, mapView: MapView): Boolean {
            val x = e.x; val y = e.y
            for (i in hitAreas.indices.reversed()) {
                val (rect, flight) = hitAreas[i]
                if (rect.contains(x, y)) {
                    // Toggle selection — tap again to deselect
                    selectedIcao = if (selectedIcao == flight.icao24) null else flight.icao24
                    mapView.invalidate()
                    return true
                }
            }
            // Tap on empty map → deselect
            selectedIcao = null
            mapView.invalidate()
            return false
        }
    }

    // ── Radius slider ─────────────────────────────────────────────────────

    private fun setupRadiusSlider() {
        binding.seekRadius.progress = radiusToProg(FlightRepository.RADIUS_DEG)
        binding.tvRadiusValue.text  = "${FlightRepository.radiusMiles} mi"
        binding.seekRadius.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                FlightRepository.RADIUS_DEG = progToRadius(p)
                binding.tvRadiusValue.text = "${FlightRepository.radiusMiles} mi"
                addRadiusCircle()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {
                lifecycleScope.launch { loadFlights() }
            }
        })
    }

    private fun radiusToProg(deg: Double) = ((deg - 0.1) / 1.8 * 90).toInt().coerceIn(0, 90)
    private fun progToRadius(p: Int)      = 0.1 + p / 90.0 * 1.8

    // ── Refresh loops ─────────────────────────────────────────────────────

    private fun startAutoRefresh() {
        lifecycleScope.launch {
            while (isActive) {
                loadFlights()
                loadWeather()
                delay(60_000L)
            }
        }
    }

    private fun startClockTick() {
        lifecycleScope.launch {
            while (isActive) {
                val now = Date()
                binding.tvMapTime.text = timeFmt.format(now)
                binding.tvMapDay.text  = dayFmt.format(now).uppercase()
                binding.tvMapDate.text = dateFmt.format(now)
                delay(1_000)
            }
        }
    }

    private suspend fun loadFlights() {
        showLoading(true)
        try {
            val flights = FlightRepository.getFlightsOverhead().sortedByDescending { it.altitudeFt }
            flightData.clear()
            flights.forEach { flightData[it.icao24] = it }
            selectedIcao = null
            chipOverlay.setFlights(flights)
            binding.map.invalidate()
            binding.tvFlightCount.text = "${flights.size} flights overhead"
        } catch (e: retrofit2.HttpException) {
            binding.tvFlightCount.text = when (e.code()) {
                429  -> "Rate limited — retrying"
                401  -> "API auth error"
                503  -> "OpenSky offline"
                else -> "API error ${e.code()}"
            }
        } catch (e: java.net.SocketTimeoutException) {
            binding.tvFlightCount.text = "Timeout — will retry"
        } catch (e: java.net.UnknownHostException) {
            binding.tvFlightCount.text = "No internet"
        } catch (e: Exception) {
            binding.tvFlightCount.text = "Error: ${e.javaClass.simpleName}"
        } finally {
            showLoading(false)
        }
    }

    private suspend fun loadWeather() {
        binding.tvWeather.text = WeatherRepository.getWeatherString()
    }

    private fun showLoading(on: Boolean) {
        binding.loadingContainer.visibility =
            if (on && flightData.isEmpty()) View.VISIBLE else View.GONE
    }

    // ── Buttons ───────────────────────────────────────────────────────────

    private fun setupClickListeners() {
        binding.btnRefresh.setOnClickListener {
            it.animate().rotation(it.rotation + 360f).setDuration(500).start()
            lifecycleScope.launch { loadFlights(); loadWeather() }
        }
    }

    // ── Background worker ─────────────────────────────────────────────────

    private fun scheduleBackgroundMonitor() {
        val req = PeriodicWorkRequestBuilder<FlightMonitorWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            FlightMonitorWorker.WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, req
        )
    }

    // ── Permissions ───────────────────────────────────────────────────────

    private fun requestPermissions() {
        val missing = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.POST_NOTIFICATIONS)
            .filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 1)
    }

    override fun onResume()  { super.onResume(); binding.map.onResume()  }
    override fun onPause()   { super.onPause();  binding.map.onPause()   }
    override fun onDestroy() {
        super.onDestroy()
        if (::pulseAnimator.isInitialized) pulseAnimator.cancel()
    }
}
