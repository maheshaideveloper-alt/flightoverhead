package com.flightoverhead

import android.Manifest
import android.animation.ValueAnimator
import android.app.Dialog
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.Surface
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.flightoverhead.data.Flight
import com.flightoverhead.data.FlightRepository
import com.flightoverhead.data.LotteryRepository
import com.flightoverhead.data.WeatherRepository
import com.flightoverhead.databinding.ActivityMainBinding
import com.flightoverhead.ui.enableMarquee
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Overlay
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private var homePoint        = GeoPoint(FlightRepository.HOME_LAT, FlightRepository.HOME_LON)
    private var currentLocName   = ""   // human-readable name of the pinned location

    // Flight state
    private val flightData      = mutableMapOf<String, Flight>()
    private val deadReckonedPos = mutableMapOf<String, GeoPoint>()
    private var lastFetchTimeMs = 0L

    // Multi-select: persists across refreshes
    private val selectedIcaos = mutableSetOf<String>()

    private lateinit var chipOverlay: FlightChipOverlay
    private var radiusOverlay: Overlay? = null

    // Animations
    private lateinit var livePulseAnimator: ValueAnimator
    private lateinit var pulseAnimator: ValueAnimator
    private var pulseRadius = 30f

    // Colours
    private val colorSkyBlue = Color.parseColor("#38BDF8")
    private val colorGreen = Color.parseColor("#4ADE80")
    private val colorRed   = Color.parseColor("#FF3B30")
    private val colorPink  = Color.parseColor("#FF69B4")

    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val dateFmt = SimpleDateFormat("MMMM d, yyyy", Locale.US)
    private val dayFmt  = SimpleDateFormat("EEEE", Locale.US)

    /** Timezone of the currently pinned location — clock formatters follow this, not the device's. */
    private var locationTimeZone: TimeZone = TimeZone.getDefault()
        set(value) {
            field = value
            timeFmt.timeZone = value
            dateFmt.timeZone = value
            dayFmt.timeZone  = value
        }

    private val httpClient = OkHttpClient()

    // Compass
    private lateinit var sensorManager: SensorManager
    private var rotationSensor: Sensor? = null
    private val rotationMatrix = FloatArray(9)
    private val remappedMatrix = FloatArray(9)
    private val orientationAngles = FloatArray(3)
    private var headingUpMode = false
    private var lastMapOrientation = 0f

    private val darkTiles = XYTileSource(
        "CartoDarkMatter", 0, 19, 256, ".png",
        arrayOf(
            "https://a.basemaps.cartocdn.com/dark_all/",
            "https://b.basemaps.cartocdn.com/dark_all/",
            "https://c.basemaps.cartocdn.com/dark_all/"
        )
    )

    // ════════════════════════════════════════════════════════════════════
    // LIFECYCLE
    // ════════════════════════════════════════════════════════════════════

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )

        Configuration.getInstance().userAgentValue = packageName
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupMarquee()
        setupMap()
        setupVideoOverlay()
        setupCompass()
        setupHomePulse()
        setupRadiusSlider()
        setupClickListeners()
        setupLottery()
        requestPermissions()
        initLocationFromGps()

        startAutoRefresh()
        startClockTick()
        startDeadReckoning()
        startLivePulse()
    }

    // ════════════════════════════════════════════════════════════════════
    // LOCATION PINNING
    // ════════════════════════════════════════════════════════════════════

    /**
     * Pins [point] as the new home.
     * If [name] is provided it is used immediately; otherwise a reverse-geocode
     * lookup runs async and fills in the name once it returns.
     */
    private fun pinLocation(point: GeoPoint, name: String? = null) {
        homePoint = point
        FlightRepository.HOME_LAT = point.latitude
        FlightRepository.HOME_LON = point.longitude

        // Show coords immediately, name will fill in shortly
        val coordStr = "%.4f° N  %.4f° W".format(point.latitude, abs(point.longitude))
        val displayName = name ?: coordStr
        currentLocName  = displayName
        updateLocationDisplay(displayName, coordStr)

        addRadiusCircle()
        binding.map.invalidate()
        lifecycleScope.launch { loadFlights(); loadWeather() }

        // If no name was given, fetch one asynchronously
        if (name == null) {
            lifecycleScope.launch {
                val fetched = reverseGeocode(point.latitude, point.longitude)
                if (fetched != null) {
                    currentLocName = fetched
                    updateLocationDisplay(fetched, coordStr)
                }
            }
        }
    }

    /** Updates every UI element that shows the current location. */
    private fun updateLocationDisplay(name: String, coords: String) {
        // Bottom card only — top bar LOCATION section removed
        binding.tvLocationName.text = name
        binding.tvMapCoords.text    = coords
    }

    /** Nominatim reverse geocoding — returns "City, Country" style name or null. */
    private suspend fun reverseGeocode(lat: Double, lon: Double): String? =
        withContext(Dispatchers.IO) {
            try {
                val url = "https://nominatim.openstreetmap.org/reverse" +
                    "?lat=$lat&lon=$lon&format=json&accept-language=en"
                val req = Request.Builder().url(url)
                    .header("User-Agent", packageName).build()
                val body = httpClient.newCall(req).execute().use { it.body?.string() }
                    ?: return@withContext null
                val json    = org.json.JSONObject(body)
                val addr    = json.optJSONObject("address")
                val city    = addr?.optString("city")?.takeIf { it.isNotEmpty() }
                    ?: addr?.optString("town")?.takeIf { it.isNotEmpty() }
                    ?: addr?.optString("village")?.takeIf { it.isNotEmpty() }
                    ?: addr?.optString("county")?.takeIf { it.isNotEmpty() }
                val state   = addr?.optString("state")?.takeIf { it.isNotEmpty() }
                val country = addr?.optString("country_code")?.uppercase()
                listOfNotNull(city, state, country).joinToString(", ").takeIf { it.isNotEmpty() }
            } catch (_: Exception) { null }
        }

    private fun initLocationFromGps() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) return
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            ?: lm.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER)
        if (loc != null) {
            pinLocation(GeoPoint(loc.latitude, loc.longitude), name = null) // reverse geocode will fill name
            binding.map.controller.setCenter(GeoPoint(loc.latitude, loc.longitude))
        }
    }

    // ════════════════════════════════════════════════════════════════════
    // SEARCH DIALOG
    // ════════════════════════════════════════════════════════════════════

    /** Simple data class for a geocoding result. */
    data class SearchResult(
        val name: String,
        val subtext: String,
        val lat: Double,
        val lon: Double
    )

    private fun showSearchDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val view = layoutInflater.inflate(R.layout.dialog_search, null)
        dialog.setContentView(view)
        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setLayout(
                (resources.displayMetrics.widthPixels * 0.44f).toInt(),
                WindowManager.LayoutParams.WRAP_CONTENT
            )
            // Resize dialog when keyboard opens so results stay visible and scrollable
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }

        val etSearch        = view.findViewById<EditText>(R.id.etSearch)
        val lvResults       = view.findViewById<ListView>(R.id.lvResults)
        val pbLoading       = view.findViewById<ProgressBar>(R.id.pbSearchLoading)
        val tvNoResults     = view.findViewById<TextView>(R.id.tvNoResults)
        val layoutMyLoc     = view.findViewById<View>(R.id.layoutMyLocation)

        // My Location tap — GPS + reverse geocode fills the name
        layoutMyLoc.setOnClickListener {
            dialog.dismiss()
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Location permission required", Toast.LENGTH_SHORT).show()
            } else {
                initLocationFromGps()
                binding.map.controller.animateTo(homePoint)
            }
        }

        var searchJob: Job? = null

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val query = s?.toString()?.trim() ?: return
                lvResults.visibility  = View.GONE
                tvNoResults.visibility = View.GONE
                pbLoading.visibility  = View.GONE

                if (query.length < 2) return

                searchJob?.cancel()
                searchJob = lifecycleScope.launch {
                    delay(400) // debounce typing
                    pbLoading.visibility = View.VISIBLE

                    val results = mutableListOf<SearchResult>()

                    // 1. Detect lat, lon input  e.g. "33.006, -96.845"
                    parseLatLon(query)?.let { (lat, lon) ->
                        results.add(SearchResult(
                            name    = "%.5f°, %.5f°".format(lat, lon),
                            subtext = "Coordinates",
                            lat     = lat,
                            lon     = lon
                        ))
                    }

                    // 2. Nominatim geocoding (places, airports, etc.)
                    try { results.addAll(searchNominatim(query)) }
                    catch (_: Exception) {}

                    pbLoading.visibility = View.GONE

                    if (results.isEmpty()) {
                        tvNoResults.visibility = View.VISIBLE
                    } else {
                        val adapter = SearchResultsAdapter(results)
                        lvResults.adapter = adapter
                        lvResults.visibility = View.VISIBLE
                        lvResults.setOnItemClickListener { _, _, pos, _ ->
                            val r = results[pos]
                            dialog.dismiss()
                            hideKeyboard(etSearch)
                            val pt = GeoPoint(r.lat, r.lon)
                            pinLocation(pt, name = r.name)   // name known — no reverse geocode needed
                            binding.map.controller.animateTo(pt)
                            binding.map.controller.setZoom(10.0)
                        }
                    }
                }
            }
        })

        dialog.show()
        etSearch.requestFocus()
        showKeyboard(etSearch)
    }

    /** Call Nominatim (OpenStreetMap geocoding). No API key required. */
    private suspend fun searchNominatim(query: String): List<SearchResult> =
        withContext(Dispatchers.IO) {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url = "https://nominatim.openstreetmap.org/search" +
                "?q=$encoded&format=json&limit=7&addressdetails=0&accept-language=en"
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", packageName)
                .build()
            val body = httpClient.newCall(req).execute().use { it.body?.string() }
                ?: return@withContext emptyList()
            val arr = JSONArray(body)
            (0 until arr.length()).mapNotNull { i ->
                val obj    = arr.getJSONObject(i)
                val full   = obj.optString("display_name")
                val parts  = full.split(",")
                val lat    = obj.optString("lat").toDoubleOrNull() ?: return@mapNotNull null
                val lon    = obj.optString("lon").toDoubleOrNull() ?: return@mapNotNull null
                // Show type badge for airports
                val type   = obj.optString("type")
                val badge  = if (type == "aerodrome") "✈ " else ""
                SearchResult(
                    name    = badge + (parts.firstOrNull()?.trim() ?: full),
                    subtext = full,
                    lat     = lat,
                    lon     = lon
                )
            }
        }

    /** Returns (lat, lon) if [query] looks like coordinate pair, else null. */
    private fun parseLatLon(query: String): Pair<Double, Double>? {
        val pattern = Regex("""^\s*(-?\d{1,3}\.?\d*)[,\s]+(-?\d{1,3}\.?\d*)\s*$""")
        val m = pattern.find(query.trim()) ?: return null
        val lat = m.groupValues[1].toDoubleOrNull() ?: return null
        val lon = m.groupValues[2].toDoubleOrNull() ?: return null
        if (lat !in -90.0..90.0 || lon !in -180.0..180.0) return null
        return Pair(lat, lon)
    }

    private inner class SearchResultsAdapter(
        private val items: List<SearchResult>
    ) : BaseAdapter() {
        override fun getCount()                  = items.size
        override fun getItem(pos: Int)           = items[pos]
        override fun getItemId(pos: Int)         = pos.toLong()

        override fun getView(pos: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView
                ?: LayoutInflater.from(this@MainActivity)
                    .inflate(R.layout.item_search_result, parent, false)
            val r = items[pos]
            v.findViewById<TextView>(R.id.tvResultName).apply { text = r.name; enableMarquee() }
            v.findViewById<TextView>(R.id.tvResultSub).apply { text = r.subtext; enableMarquee() }
            return v
        }
    }

    private fun showKeyboard(v: View) {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .showSoftInput(v, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideKeyboard(v: View) {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(v.windowToken, 0)
    }

    // ════════════════════════════════════════════════════════════════════
    // PERMISSIONS
    // ════════════════════════════════════════════════════════════════════

    private fun requestPermissions() {
        val missing = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION
        ).filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty())
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.any { it == PackageManager.PERMISSION_GRANTED })
            initLocationFromGps()
    }

    // ════════════════════════════════════════════════════════════════════
    // ANIMATIONS
    // ════════════════════════════════════════════════════════════════════

    private fun startLivePulse() {
        livePulseAnimator = ValueAnimator.ofFloat(0.35f, 1.0f).apply {
            duration     = 1200
            repeatCount  = ValueAnimator.INFINITE
            repeatMode   = ValueAnimator.REVERSE
            interpolator = LinearInterpolator()
            addUpdateListener { binding.tvLiveDot.alpha = it.animatedValue as Float }
            start()
        }
    }

    private fun startDeadReckoning() {
        lifecycleScope.launch {
            while (isActive) {
                delay(1_000L)
                if (lastFetchTimeMs == 0L || flightData.isEmpty()) continue
                val dt = ((System.currentTimeMillis() - lastFetchTimeMs) / 1000.0).coerceAtMost(90.0)
                for ((icao, flight) in flightData) {
                    val hr   = Math.toRadians(flight.heading)
                    val dLat = (flight.velocity * cos(hr) * dt) / 111_320.0
                    val dLon = (flight.velocity * sin(hr) * dt) /
                               (111_320.0 * cos(Math.toRadians(flight.latitude)))
                    deadReckonedPos[icao] = GeoPoint(flight.latitude + dLat, flight.longitude + dLon)
                }
                binding.map.invalidate()
            }
        }
    }

    // ════════════════════════════════════════════════════════════════════
    // TEXT OVERFLOW — any label whose content length varies at runtime
    // scrolls horizontally within its own allocated space once it's too
    // long to fit, instead of wrapping or spilling into neighboring UI.
    // ════════════════════════════════════════════════════════════════════

    private fun setupMarquee() {
        binding.tvFlightCount.enableMarquee()
        binding.tvMapDay.enableMarquee()
        binding.tvMapDate.enableMarquee()
        binding.tvMapTime.enableMarquee()
        binding.tvWeather.enableMarquee()
        binding.tvLocationName.enableMarquee()
        binding.tvMapCoords.enableMarquee()
    }

    // ════════════════════════════════════════════════════════════════════
    // COMPASS — the rose (needle + N/E/S/W) always rotates to point true
    // north, accounting for whichever way the device is currently rotated
    // (sensorLandscape allows either landscape orientation). The switch
    // beside it toggles "heading-up" mode, which additionally rotates the
    // whole map so the direction you're facing is at the top of the screen —
    // handy for matching a blip on screen to a plane in the actual sky.
    // ════════════════════════════════════════════════════════════════════

    private fun setupCompass() {
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        binding.headingToggle.setOnCheckedChangeListener { _, isChecked ->
            headingUpMode = isChecked
            if (!headingUpMode) {
                binding.map.mapOrientation = 0f
                lastMapOrientation = 0f
                binding.map.invalidate()
            }
        }
    }

    private fun registerCompass() {
        rotationSensor?.let {
            sensorManager.registerListener(compassListener, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    private fun unregisterCompass() {
        if (::sensorManager.isInitialized) sensorManager.unregisterListener(compassListener)
    }

    private val compassListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)

            @Suppress("DEPRECATION")
            val rotation = windowManager.defaultDisplay.rotation
            val (axisX, axisY) = when (rotation) {
                Surface.ROTATION_90  -> SensorManager.AXIS_Y to SensorManager.AXIS_MINUS_X
                Surface.ROTATION_180 -> SensorManager.AXIS_MINUS_X to SensorManager.AXIS_MINUS_Y
                Surface.ROTATION_270 -> SensorManager.AXIS_MINUS_Y to SensorManager.AXIS_X
                else                 -> SensorManager.AXIS_X to SensorManager.AXIS_Y
            }
            SensorManager.remapCoordinateSystem(rotationMatrix, axisX, axisY, remappedMatrix)
            SensorManager.getOrientation(remappedMatrix, orientationAngles)

            val azimuthDeg = Math.toDegrees(orientationAngles[0].toDouble()).toFloat()
            // Rose is drawn N-up at baseline. If facing bearing θ, true north sits
            // at screen angle -θ (e.g. facing due West/270°, north is 90° to your
            // right — verified against a phone compass reference on a physical
            // landscape-natural tablet). A prior attempt removed this negation
            // based on a report that turned out to be a stale/not-yet-rebuilt app;
            // photographic ground-truth testing confirmed negated is correct.
            val roseRotation = -((azimuthDeg + 360f) % 360f)
            binding.compassRose.rotation = roseRotation

            if (headingUpMode) {
                val target = ((roseRotation % 360f) + 360f) % 360f
                if (abs(target - lastMapOrientation) > 2f) {
                    binding.map.mapOrientation = target
                    lastMapOrientation = target
                    binding.map.invalidate()
                }
            }
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    // ════════════════════════════════════════════════════════════════════
    // MAP
    // ════════════════════════════════════════════════════════════════════

    private fun setupMap() {
        binding.map.apply {
            setTileSource(darkTiles)
            setMultiTouchControls(true)
            controller.setZoom(9.5)
            controller.setCenter(homePoint)
            isTilesScaledToDpi = true
        }
        addRadiusCircle()
        addHomeDotOverlay()
        chipOverlay = FlightChipOverlay()
        binding.map.overlays.add(chipOverlay)

        // Long-press on map → pin that location (name resolved async)
        binding.map.overlays.add(object : Overlay() {
            override fun onLongPress(e: MotionEvent, mapView: MapView): Boolean {
                val pt = mapView.projection.fromPixels(e.x.toInt(), e.y.toInt())
                val gp = GeoPoint(pt.latitude, pt.longitude)
                pinLocation(gp, name = null)
                Toast.makeText(this@MainActivity, "Location pinned", Toast.LENGTH_SHORT).show()
                return true
            }
        })

        // Seed the display with default coords (name resolves after first GPS or search)
        val defaultCoords = "%.4f° N  %.4f° W".format(FlightRepository.HOME_LAT, abs(FlightRepository.HOME_LON))
        updateLocationDisplay("North Texas", defaultCoords)
    }

    private fun setupHomePulse() {
        pulseAnimator = ValueAnimator.ofFloat(16f, 64f).apply {
            duration    = 2000; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.RESTART
            addUpdateListener { pulseRadius = it.animatedValue as Float; binding.map.invalidate() }
            start()
        }
    }

    private fun addHomeDotOverlay() {
        val pulsePaint  = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL }
        val dotPaint    = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL; color = colorGreen }
        val ringPaint   = Paint().apply { isAntiAlias = true; style = Paint.Style.STROKE; strokeWidth = 2.5f; color = colorGreen }
        val shadowPaint = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL; color = Color.argb(60, 0, 0, 0) }
        binding.map.overlays.add(object : Overlay() {
            override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
                if (shadow) return
                val c  = mapView.projection.toPixels(homePoint, null)
                val cx = c.x.toFloat(); val cy = c.y.toFloat()
                val frac = (pulseRadius - 16f) / 48f
                pulsePaint.color = Color.argb(((1f - frac) * 90f).toInt().coerceIn(0, 90), 74, 222, 128)
                canvas.drawCircle(cx, cy, pulseRadius, pulsePaint)
                canvas.drawCircle(cx, cy + 2f, 11f, shadowPaint)
                canvas.drawCircle(cx, cy, 9f, dotPaint)
                canvas.drawCircle(cx, cy, 9f, ringPaint)
            }
        })
    }

    private fun addRadiusCircle() {
        radiusOverlay?.let { binding.map.overlays.remove(it) }
        val rad    = FlightRepository.radiusDeg
        val centre = GeoPoint(homePoint.latitude, homePoint.longitude)
        val fill   = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL;   color = Color.argb(18, 56, 189, 248) }
        val stroke = Paint().apply { isAntiAlias = true; style = Paint.Style.STROKE; color = Color.argb(90, 56, 189, 248); strokeWidth = 1.5f }
        val ov = object : Overlay() {
            override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
                if (shadow) return
                val proj = mapView.projection
                val c = proj.toPixels(centre, null)
                val e = proj.toPixels(GeoPoint(centre.latitude + rad, centre.longitude), null)
                val r = abs(c.y - e.y).toFloat()
                canvas.drawCircle(c.x.toFloat(), c.y.toFloat(), r, fill)
                canvas.drawCircle(c.x.toFloat(), c.y.toFloat(), r, stroke)
            }
        }
        binding.map.overlays.add(ov)
        radiusOverlay = ov
        binding.map.invalidate()
    }

    // ════════════════════════════════════════════════════════════════════
    // FLIGHT CHIP OVERLAY
    // ════════════════════════════════════════════════════════════════════

    private inner class FlightChipOverlay : Overlay() {

        private var flights: List<Flight> = emptyList()
        private val hitAreas = ArrayList<Pair<RectF, Flight>>(32)

        private val bgPaint    = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.argb(192, 3, 11, 26) }
        private val bordPaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val txtPaint   = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 24f; typeface = Typeface.DEFAULT_BOLD; color = Color.WHITE }
        private val planePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val planePath  = Path()

        fun setFlights(list: List<Flight>) { flights = list }

        override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
            if (shadow) return
            hitAreas.clear()
            // In heading-up mode the whole canvas is pre-rotated by osmdroid before
            // this runs; counter-rotate just the text chip (not the plane icon,
            // which should keep pointing its real compass heading) so callsigns
            // stay upright no matter which way the map is currently facing.
            val mapRotation = mapView.mapOrientation
            for (flight in flights) {
                val pos = deadReckonedPos[flight.icao24] ?: GeoPoint(flight.latitude, flight.longitude)
                val pt  = mapView.projection.toPixels(pos, null)
                drawFlight(canvas, pt.x.toFloat(), pt.y.toFloat(), flight, mapRotation)
            }
        }

        private fun drawFlight(canvas: Canvas, cx: Float, cy: Float, flight: Flight, mapRotation: Float) {
            val selected = flight.icao24 in selectedIcaos
            val accent   = if (selected) colorPink else colorRed
            val s = 14f

            planePaint.color = accent
            canvas.save()
            canvas.rotate(flight.heading.toFloat(), cx, cy)
            buildPlanePath(cx, cy, s)
            canvas.drawPath(planePath, planePaint)
            canvas.restore()

            val label = flight.callsignClean
            val tw    = txtPaint.measureText(label)
            val pH = 12f; val pV = 6f
            val chipW = tw + pH * 2f; val chipH = txtPaint.textSize + pV * 2f
            val left  = cx - chipW / 2f; val top = cy + s * 2.2f + 4f
            val rect  = RectF(left, top, left + chipW, top + chipH)

            canvas.save()
            canvas.rotate(-mapRotation, cx, cy)
            canvas.drawRoundRect(rect, 8f, 8f, bgPaint)
            bordPaint.color       = accent
            bordPaint.strokeWidth = if (selected) 2.5f else 1.5f
            canvas.drawRoundRect(rect, 8f, 8f, bordPaint)
            canvas.drawText(label, left + pH, top + pV + txtPaint.textSize * 0.85f, txtPaint)
            canvas.restore()
            hitAreas.add(Pair(RectF(cx - s * 2.2f, cy - s * 2.2f, cx + s * 2.2f, top + chipH), flight))
        }

        private fun buildPlanePath(cx: Float, cy: Float, s: Float) {
            planePath.reset()
            planePath.moveTo(cx, cy - s * 2.0f); planePath.lineTo(cx + s * 0.22f, cy - s * 0.8f)
            planePath.lineTo(cx + s * 0.22f, cy + s * 1.3f); planePath.lineTo(cx, cy + s * 1.6f)
            planePath.lineTo(cx - s * 0.22f, cy + s * 1.3f); planePath.lineTo(cx - s * 0.22f, cy - s * 0.8f)
            planePath.close()
            planePath.moveTo(cx, cy - s * 0.4f); planePath.lineTo(cx + s * 2.0f, cy + s * 0.7f)
            planePath.lineTo(cx + s * 1.6f, cy + s * 1.0f); planePath.lineTo(cx + s * 0.2f, cy + s * 0.5f)
            planePath.lineTo(cx - s * 0.2f, cy + s * 0.5f); planePath.lineTo(cx - s * 1.6f, cy + s * 1.0f)
            planePath.lineTo(cx - s * 2.0f, cy + s * 0.7f); planePath.close()
            planePath.moveTo(cx, cy + s * 1.0f); planePath.lineTo(cx + s * 0.9f, cy + s * 1.5f)
            planePath.lineTo(cx + s * 0.2f, cy + s * 1.6f); planePath.lineTo(cx - s * 0.2f, cy + s * 1.6f)
            planePath.lineTo(cx - s * 0.9f, cy + s * 1.5f); planePath.close()
        }

        override fun onSingleTapConfirmed(e: MotionEvent, mapView: MapView): Boolean {
            val x = e.x; val y = e.y
            for (i in hitAreas.indices.reversed()) {
                val (rect, flight) = hitAreas[i]
                if (rect.contains(x, y)) {
                    if (flight.icao24 in selectedIcaos) selectedIcaos.remove(flight.icao24)
                    else selectedIcaos.add(flight.icao24)
                    mapView.invalidate()
                    return true
                }
            }
            return false
        }
    }

    // ════════════════════════════════════════════════════════════════════
    // RADIUS SLIDER
    // ════════════════════════════════════════════════════════════════════

    private fun setupRadiusSlider() {
        binding.seekRadius.max      = 99 // progress 0..99 -> 1..100 miles, 1-mile steps
        binding.seekRadius.progress = radiusToProg(FlightRepository.RADIUS_MILES)
        binding.tvRadiusValue.text  = "${FlightRepository.RADIUS_MILES} mi"
        binding.seekRadius.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                FlightRepository.RADIUS_MILES = progToRadius(p)
                binding.tvRadiusValue.text = "${FlightRepository.RADIUS_MILES} mi"
                addRadiusCircle()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) { lifecycleScope.launch { loadFlights() } }
        })
    }

    private fun radiusToProg(miles: Int) = (miles - 1).coerceIn(0, 99)
    private fun progToRadius(p: Int)     = p + 1

    // ════════════════════════════════════════════════════════════════════
    // REFRESH LOOPS
    // ════════════════════════════════════════════════════════════════════

    private fun startAutoRefresh() {
        lifecycleScope.launch {
            while (isActive) {
                playRefreshOverlay() // automatic refresh only — manual tap never calls this
                loadFlights(); loadWeather()
                delay(60_000L)
            }
        }
    }

    // ════════════════════════════════════════════════════════════════════
    // REFRESH OVERLAY — full-screen video shown once per automatic refresh
    // (including the very first load), never on a manual refresh tap.
    // ════════════════════════════════════════════════════════════════════

    private fun setupVideoOverlay() {
        val uri = Uri.parse("android.resource://$packageName/${R.raw.overlay_refresh}")
        binding.videoOverlay.isLoopPlayback = false
        binding.videoOverlay.setVideoURI(uri)
        binding.videoOverlay.onCompletion = {
            binding.videoOverlay.animate()
                .alpha(0f)
                .setDuration(250)
                .withEndAction { binding.videoOverlay.visibility = View.GONE }
                .start()
        }
    }

    private fun playRefreshOverlay() {
        binding.videoOverlay.apply {
            visibility = View.VISIBLE
            alpha = 0f
            animate().alpha(1f).setDuration(200).start()
            seekAndPlay() // no-op if the player isn't prepared yet; first play auto-starts once ready
        }
    }

    private fun startClockTick() {
        lifecycleScope.launch {
            while (isActive) {
                val now = Date()
                binding.tvMapTime.text = timeFmt.format(now)
                binding.tvMapDay.text  = dayFmt.format(now).uppercase()
                binding.tvMapDate.text = dateFmt.format(now)
                delay(1_000L)
            }
        }
    }

    private suspend fun loadFlights() {
        showLoading(true)
        try {
            val flights = FlightRepository.getFlightsOverhead().sortedByDescending { it.altitudeFt }
            flightData.clear(); flights.forEach { flightData[it.icao24] = it }
            deadReckonedPos.clear(); flights.forEach { deadReckonedPos[it.icao24] = GeoPoint(it.latitude, it.longitude) }
            lastFetchTimeMs = System.currentTimeMillis()
            selectedIcaos.retainAll(flights.map { it.icao24 }.toSet())
            chipOverlay.setFlights(flights)
            binding.map.invalidate()
            binding.tvFlightCount.text = "${flights.size} flights"
        } catch (e: retrofit2.HttpException) {
            binding.tvFlightCount.text = when (e.code()) { 429 -> "rate limited"; 401 -> "auth error"; else -> "error" }
        } catch (_: Exception) { binding.tvFlightCount.text = "error" }
        finally { showLoading(false) }
    }

    private suspend fun loadWeather() {
        val info = WeatherRepository.getWeatherInfo(homePoint.latitude, homePoint.longitude)
        binding.tvWeather.text = info.text
        info.timeZoneId?.let { tzId ->
            val tz = TimeZone.getTimeZone(tzId)
            // getTimeZone() silently falls back to GMT for an unrecognized id — only trust it
            // if the id actually round-tripped, so a bad API response can't zero out the clock.
            if (tz.id == tzId && tz.id != locationTimeZone.id) locationTimeZone = tz
        }
    }

    private fun showLoading(on: Boolean) {
        binding.loadingContainer.visibility = if (on && flightData.isEmpty()) View.VISIBLE else View.GONE
    }

    // ════════════════════════════════════════════════════════════════════
    // BUTTONS
    // ════════════════════════════════════════════════════════════════════

    private fun setupClickListeners() {
        binding.btnRefresh.setOnClickListener {
            it.animate().rotation(it.rotation + 360f).setDuration(500).start()
            lifecycleScope.launch { loadFlights(); loadWeather(); loadLottery() }
        }
        binding.btnSearch.setOnClickListener { showSearchDialog() }
    }

    // ════════════════════════════════════════════════════════════════════
    // LOTTERY — Powerball + Mega Millions winning numbers and live jackpot.
    // Fetched once at startup and again on manual refresh (not on the 60s
    // auto-refresh loop — draws only happen a few times a week, so polling
    // that often would just hammer the source site for no benefit).
    // ════════════════════════════════════════════════════════════════════

    private fun setupLottery() {
        lifecycleScope.launch { loadLottery() }
    }

    private suspend fun loadLottery() {
        val powerball = LotteryRepository.getResult(LotteryRepository.Game.POWERBALL)
        if (powerball != null) {
            binding.tvPowerballJackpot.text = powerball.jackpot
            renderBalls(binding.ballsPowerball, powerball, R.drawable.bg_ball_red)
        }

        val megaMillions = LotteryRepository.getResult(LotteryRepository.Game.MEGA_MILLIONS)
        if (megaMillions != null) {
            binding.tvMegaMillionsJackpot.text = megaMillions.jackpot
            renderBalls(binding.ballsMegaMillions, megaMillions, R.drawable.bg_ball_gold)
        }
    }

    /** Draws small gas-station-terminal-style number balls into [container]. */
    private fun renderBalls(
        container: LinearLayout,
        result: LotteryRepository.LotteryResult,
        bonusBallBg: Int
    ) {
        container.removeAllViews()
        val ballSize = (22 * resources.displayMetrics.density).toInt()
        val marginEnd = (4 * resources.displayMetrics.density).toInt()

        fun addBall(number: Int, background: Int, textColor: Int) {
            val ball = TextView(this).apply {
                text = number.toString()
                textSize = 10f
                gravity = android.view.Gravity.CENTER
                setTextColor(textColor)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setBackgroundResource(background)
            }
            val params = LinearLayout.LayoutParams(ballSize, ballSize)
            params.marginEnd = marginEnd
            container.addView(ball, params)
        }

        result.numbers.forEach { addBall(it, R.drawable.bg_ball_white, Color.BLACK) }
        addBall(result.bonusBall, bonusBallBg, Color.WHITE)
    }

    override fun onResume() {
        super.onResume()
        binding.map.onResume()
        registerCompass()
    }
    override fun onPause() {
        super.onPause()
        binding.map.onPause()
        binding.videoOverlay.pause()
        unregisterCompass()
    }
    override fun onDestroy() {
        super.onDestroy()
        if (::pulseAnimator.isInitialized)     pulseAnimator.cancel()
        if (::livePulseAnimator.isInitialized) livePulseAnimator.cancel()
        binding.videoOverlay.stopPlayback()
    }
}
