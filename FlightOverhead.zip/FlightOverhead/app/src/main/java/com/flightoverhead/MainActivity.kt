package com.flightoverhead

import android.Manifest
import android.animation.ValueAnimator
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.work.*
import com.flightoverhead.data.Flight
import com.flightoverhead.data.FlightRepository
import com.flightoverhead.data.WeatherRepository
import com.flightoverhead.databinding.ActivityMainBinding
import com.flightoverhead.service.FlightMonitorWorker
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Overlay
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val homePoint = GeoPoint(FlightRepository.HOME_LAT, FlightRepository.HOME_LON)

    // ── Flight state ──────────────────────────────────────────────────────
    private val flightData = mutableMapOf<String, Flight>()

    // Feature 2: dead-reckoned positions updated every second
    private val deadReckonedPos = mutableMapOf<String, GeoPoint>()
    private var lastFetchTimeMs  = 0L

    // Feature 4: new-flight flash tracking
    private var previousIcaos  = emptySet<String>()
    private val newFlightFlash = mutableMapOf<String, Long>() // icao → timestamp detected

    // ── UI state ──────────────────────────────────────────────────────────
    private var selectedIcao: String? = null
    private var refreshCountdown = 60        // Feature 1

    private lateinit var chipOverlay: FlightChipOverlay
    private var radiusOverlay: Overlay? = null

    // Feature 5: pulse animator for the LIVE dot
    private lateinit var livePulseAnimator: ValueAnimator
    // Home-dot pulse
    private var pulseRadius = 30f
    private lateinit var pulseAnimator: ValueAnimator

    // ── Formatting ────────────────────────────────────────────────────────
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val dateFmt = SimpleDateFormat("MMMM d, yyyy", Locale.US)
    private val dayFmt  = SimpleDateFormat("EEEE", Locale.US)

    private val darkTiles = XYTileSource(
        "CartoDarkMatter", 0, 19, 256, ".png",
        arrayOf(
            "https://a.basemaps.cartocdn.com/dark_all/",
            "https://b.basemaps.cartocdn.com/dark_all/",
            "https://c.basemaps.cartocdn.com/dark_all/"
        )
    )

    // ── Colours ───────────────────────────────────────────────────────────
    private val colorCyan    = Color.parseColor("#00D4FF")
    private val colorMagenta = Color.parseColor("#FF2D78")

    /** Feature 3 — altitude-coded plane colour */
    private fun altitudeColor(altFt: Int) = when {
        altFt < 10_000 -> Color.parseColor("#4ADE80") // green  — low-altitude
        altFt < 25_000 -> Color.parseColor("#FFD700") // gold   — mid-altitude
        altFt < 40_000 -> colorCyan                   // cyan   — cruise
        else           -> Color.parseColor("#FFFFFF")  // white  — very high
    }

    // ─────────────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )

        Configuration.getInstance().userAgentValue = packageName
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupMap()
        setupHomePulse()
        setupRadiusSlider()
        setupClickListeners()
        requestPermissions()

        // Static coords label
        binding.tvMapCoords.text =
            "%.4f° N  %.4f° W".format(FlightRepository.HOME_LAT, abs(FlightRepository.HOME_LON))

        // Start all live loops
        startAutoRefresh()          // 60s API fetch
        startClockTick()            // 1s clock
        startCountdown()            // Feature 1 — ticking countdown
        startDeadReckoning()        // Feature 2 — smooth plane movement
        startLivePulse()            // Feature 5 — pulsing ● dot
        scheduleBackgroundMonitor()
    }

    // ════════════════════════════════════════════════════════════════════
    // FEATURE 1 — Countdown to next refresh
    // ════════════════════════════════════════════════════════════════════

    private fun startCountdown() {
        lifecycleScope.launch {
            while (isActive) {
                delay(1_000L)
                if (refreshCountdown > 0) refreshCountdown--
                binding.tvCountdown.text = "↻ ${refreshCountdown}s"
            }
        }
    }

    // ════════════════════════════════════════════════════════════════════
    // FEATURE 2 — Dead-reckoning between API fetches
    // Updates plane screen positions every second using speed + heading.
    // ════════════════════════════════════════════════════════════════════

    private fun startDeadReckoning() {
        lifecycleScope.launch {
            while (isActive) {
                delay(1_000L)
                if (lastFetchTimeMs == 0L || flightData.isEmpty()) continue

                // Seconds elapsed since the last real API fetch (cap at 90s)
                val dt = ((System.currentTimeMillis() - lastFetchTimeMs) / 1000.0).coerceAtMost(90.0)

                for ((icao, flight) in flightData) {
                    val headingRad = Math.toRadians(flight.heading)
                    val speedMps   = flight.velocity                    // m/s from OpenSky

                    // Simple flat-earth approximation — accurate enough for a 60s window
                    val dLat = (speedMps * cos(headingRad) * dt) / 111_320.0
                    val dLon = (speedMps * sin(headingRad) * dt) /
                               (111_320.0 * cos(Math.toRadians(flight.latitude)))

                    deadReckonedPos[icao] = GeoPoint(
                        flight.latitude  + dLat,
                        flight.longitude + dLon
                    )
                }

                binding.map.invalidate()
            }
        }
    }

    // ════════════════════════════════════════════════════════════════════
    // FEATURE 5 — Pulsing LIVE dot
    // ════════════════════════════════════════════════════════════════════

    private fun startLivePulse() {
        livePulseAnimator = ValueAnimator.ofFloat(0.35f, 1.0f).apply {
            duration        = 1200
            repeatCount     = ValueAnimator.INFINITE
            repeatMode      = ValueAnimator.REVERSE
            interpolator    = LinearInterpolator()
            addUpdateListener { binding.tvLiveDot.alpha = it.animatedValue as Float }
            start()
        }
    }

    // ════════════════════════════════════════════════════════════════════
    // MAP SETUP
    // ════════════════════════════════════════════════════════════════════

    private fun setupMap() {
        binding.map.apply {
            setTileSource(darkTiles)
            setMultiTouchControls(true)
            controller.setZoom(9.5)
            controller.setCenter(homePoint)
            isTilesScaledToDpi = true
        }
        addRadiusCircle()
        addHomeDotOverlay()
        chipOverlay = FlightChipOverlay()
        binding.map.overlays.add(chipOverlay)
    }

    private fun setupHomePulse() {
        pulseAnimator = ValueAnimator.ofFloat(16f, 64f).apply {
            duration     = 2000
            repeatCount  = ValueAnimator.INFINITE
            repeatMode   = ValueAnimator.RESTART
            addUpdateListener { pulseRadius = it.animatedValue as Float; binding.map.invalidate() }
            start()
        }
    }

    private fun addHomeDotOverlay() {
        val pulsePaint  = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL }
        val dotPaint    = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL; color = Color.WHITE }
        val ringPaint   = Paint().apply { isAntiAlias = true; style = Paint.Style.STROKE; strokeWidth = 2.5f; color = colorCyan }
        val shadowPaint = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL; color = Color.argb(60, 0, 0, 0) }

        binding.map.overlays.add(object : Overlay() {
            override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
                if (shadow) return
                val c  = mapView.projection.toPixels(homePoint, null)
                val cx = c.x.toFloat(); val cy = c.y.toFloat()
                val frac = (pulseRadius - 16f) / 48f
                pulsePaint.color = Color.argb(((1f - frac) * 90f).toInt().coerceIn(0, 90), 0, 212, 255)
                canvas.drawCircle(cx, cy, pulseRadius, pulsePaint)
                canvas.drawCircle(cx, cy + 2f, 11f, shadowPaint)
                canvas.drawCircle(cx, cy, 9f, dotPaint)
                canvas.drawCircle(cx, cy, 9f, ringPaint)
            }
        })
    }

    private fun addRadiusCircle() {
        radiusOverlay?.let { binding.map.overlays.remove(it) }
        val rad    = FlightRepository.RADIUS_DEG
        val fill   = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL;   color = Color.argb(12, 0, 212, 255) }
        val stroke = Paint().apply { isAntiAlias = true; style = Paint.Style.STROKE; color = Color.argb(70, 0, 212, 255); strokeWidth = 1.5f }
        val ov = object : Overlay() {
            override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
                if (shadow) return
                val proj = mapView.projection
                val c = proj.toPixels(homePoint, null)
                val e = proj.toPixels(GeoPoint(homePoint.latitude + rad, homePoint.longitude), null)
                val r = abs(c.y - e.y).toFloat()
                canvas.drawCircle(c.x.toFloat(), c.y.toFloat(), r, fill)
                canvas.drawCircle(c.x.toFloat(), c.y.toFloat(), r, stroke)
            }
        }
        binding.map.overlays.add(ov)
        radiusOverlay = ov
        binding.map.invalidate()
    }

    // ════════════════════════════════════════════════════════════════════
    // FLIGHT CHIP OVERLAY
    // Features 2, 3, 4 all live here in draw().
    // ════════════════════════════════════════════════════════════════════

    private inner class FlightChipOverlay : Overlay() {

        private var flights: List<Flight> = emptyList()
        private val hitAreas = ArrayList<Pair<RectF, Flight>>(32)

        private val bgPaint   = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val bordPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val txtPaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 24f; typeface = Typeface.DEFAULT_BOLD; color = Color.WHITE
        }
        private val planePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val glowPaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val planePath  = Path()

        fun setFlights(list: List<Flight>) { flights = list }

        override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
            if (shadow) return
            hitAreas.clear()
            val now = System.currentTimeMillis()

            for (flight in flights) {
                // Feature 2 — use dead-reckoned position if available
                val pos = deadReckonedPos[flight.icao24]
                    ?: GeoPoint(flight.latitude, flight.longitude)
                val pt = mapView.projection.toPixels(pos, null)
                drawFlight(canvas, pt.x.toFloat(), pt.y.toFloat(), flight, now)
            }
        }

        private fun drawFlight(canvas: Canvas, cx: Float, cy: Float, flight: Flight, now: Long) {
            val selected = flight.icao24 == selectedIcao

            // Feature 4 — new-flight flash: magenta for 2s after first appearance
            val isNewFlash = newFlightFlash[flight.icao24]?.let { now - it < 2_000L } == true

            // Feature 3 — altitude-coded colour (override with magenta if selected or flashing)
            val accentColor = when {
                selected   -> colorMagenta
                isNewFlash -> colorMagenta
                else       -> altitudeColor(flight.altitudeFt)
            }

            val s = 14f
            val r = Color.red(accentColor); val g = Color.green(accentColor); val b = Color.blue(accentColor)
            val glowAlpha = if (selected || isNewFlash) 65 else 30

            // ── Glow pass ─────────────────────────────────────────────
            glowPaint.color = Color.argb(glowAlpha, r, g, b)
            canvas.save()
            canvas.rotate(flight.heading.toFloat(), cx, cy)
            canvas.scale(1.5f, 1.5f, cx, cy)
            buildPlanePath(cx, cy, s)
            canvas.drawPath(planePath, glowPaint)
            canvas.restore()

            // ── Plane silhouette ──────────────────────────────────────
            planePaint.color = accentColor
            canvas.save()
            canvas.rotate(flight.heading.toFloat(), cx, cy)
            buildPlanePath(cx, cy, s)
            canvas.drawPath(planePath, planePaint)
            canvas.restore()

            // ── Label chip ────────────────────────────────────────────
            val label = flight.callsignClean
            val tw    = txtPaint.measureText(label)
            val pH = 12f; val pV = 6f
            val chipW = tw + pH * 2f
            val chipH = txtPaint.textSize + pV * 2f

            val left = cx - chipW / 2f
            val top  = cy + s * 2.2f + 4f
            val rect = RectF(left, top, left + chipW, top + chipH)

            bgPaint.color = Color.argb(192, 3, 11, 26)
            canvas.drawRoundRect(rect, 8f, 8f, bgPaint)

            bordPaint.color       = accentColor
            bordPaint.strokeWidth = if (selected || isNewFlash) 2.5f else 1.5f
            bordPaint.alpha       = if (selected || isNewFlash) 255 else 180
            canvas.drawRoundRect(rect, 8f, 8f, bordPaint)

            canvas.drawText(label, left + pH, top + pV + txtPaint.textSize * 0.85f, txtPaint)

            hitAreas.add(Pair(
                RectF(cx - s * 2.2f, cy - s * 2.2f, cx + s * 2.2f, top + chipH),
                flight
            ))
        }

        private fun buildPlanePath(cx: Float, cy: Float, s: Float) {
            planePath.reset()
            // Fuselage
            planePath.moveTo(cx,              cy - s * 2.0f)
            planePath.lineTo(cx + s * 0.22f,  cy - s * 0.8f)
            planePath.lineTo(cx + s * 0.22f,  cy + s * 1.3f)
            planePath.lineTo(cx,              cy + s * 1.6f)
            planePath.lineTo(cx - s * 0.22f,  cy + s * 1.3f)
            planePath.lineTo(cx - s * 0.22f,  cy - s * 0.8f)
            planePath.close()
            // Wings
            planePath.moveTo(cx,              cy - s * 0.4f)
            planePath.lineTo(cx + s * 2.0f,   cy + s * 0.7f)
            planePath.lineTo(cx + s * 1.6f,   cy + s * 1.0f)
            planePath.lineTo(cx + s * 0.2f,   cy + s * 0.5f)
            planePath.lineTo(cx - s * 0.2f,   cy + s * 0.5f)
            planePath.lineTo(cx - s * 1.6f,   cy + s * 1.0f)
            planePath.lineTo(cx - s * 2.0f,   cy + s * 0.7f)
            planePath.close()
            // Tail fins
            planePath.moveTo(cx,              cy + s * 1.0f)
            planePath.lineTo(cx + s * 0.9f,   cy + s * 1.5f)
            planePath.lineTo(cx + s * 0.2f,   cy + s * 1.6f)
            planePath.lineTo(cx - s * 0.2f,   cy + s * 1.6f)
            planePath.lineTo(cx - s * 0.9f,   cy + s * 1.5f)
            planePath.close()
        }

        override fun onSingleTapConfirmed(e: MotionEvent, mapView: MapView): Boolean {
            val x = e.x; val y = e.y
            for (i in hitAreas.indices.reversed()) {
                val (rect, flight) = hitAreas[i]
                if (rect.contains(x, y)) {
                    selectedIcao = if (selectedIcao == flight.icao24) null else flight.icao24
                    mapView.invalidate()
                    return true
                }
            }
            selectedIcao = null
            mapView.invalidate()
            return false
        }
    }

    // ════════════════════════════════════════════════════════════════════
    // REFRESH LOOPS
    // ════════════════════════════════════════════════════════════════════

    private fun startAutoRefresh() {
        lifecycleScope.launch {
            while (isActive) {
                loadFlights()
                loadWeather()
                delay(60_000L)
            }
        }
    }

    private fun startClockTick() {
        lifecycleScope.launch {
            while (isActive) {
                val now = Date()
                binding.tvMapTime.text = timeFmt.format(now)
                binding.tvMapDay.text  = dayFmt.format(now).uppercase()
                binding.tvMapDate.text = dateFmt.format(now)
                delay(1_000L)
            }
        }
    }

    private suspend fun loadFlights() {
        showLoading(true)
        binding.tvCountdown.text = "loading…"
        try {
            val flights = FlightRepository.getFlightsOverhead().sortedByDescending { it.altitudeFt }

            // Feature 4 — detect brand-new flights
            val currentIcaos = flights.map { it.icao24 }.toSet()
            val freshIcaos   = currentIcaos - previousIcaos
            val now          = System.currentTimeMillis()
            freshIcaos.forEach { newFlightFlash[it] = now }
            // Clean up expired flashes
            newFlightFlash.entries.removeAll { now - it.value > 3_000L }
            previousIcaos = currentIcaos

            // Update flight state
            flightData.clear()
            flights.forEach { flightData[it.icao24] = it }
            // Seed dead-reckoned positions at the real fetched positions
            deadReckonedPos.clear()
            flights.forEach { deadReckonedPos[it.icao24] = GeoPoint(it.latitude, it.longitude) }
            lastFetchTimeMs = System.currentTimeMillis()

            selectedIcao = null
            chipOverlay.setFlights(flights)
            binding.map.invalidate()
            binding.tvFlightCount.text = "${flights.size} flights"

            // Feature 1 — reset countdown
            refreshCountdown = 60

        } catch (e: retrofit2.HttpException) {
            binding.tvFlightCount.text = when (e.code()) {
                429  -> "rate limited"; 401 -> "auth error"; 503 -> "API offline"
                else -> "error ${e.code()}"
            }
        } catch (e: java.net.SocketTimeoutException) { binding.tvFlightCount.text = "timeout" }
        catch (e: java.net.UnknownHostException)     { binding.tvFlightCount.text = "no internet" }
        catch (e: Exception)                          { binding.tvFlightCount.text = "error" }
        finally { showLoading(false) }
    }

    private suspend fun loadWeather() {
        binding.tvWeather.text = WeatherRepository.getWeatherString()
    }

    private fun showLoading(on: Boolean) {
        binding.loadingContainer.visibility =
            if (on && flightData.isEmpty()) View.VISIBLE else View.GONE
    }

    // ════════════════════════════════════════════════════════════════════
    // RADIUS SLIDER
    // ════════════════════════════════════════════════════════════════════

    private fun setupRadiusSlider() {
        binding.seekRadius.progress = radiusToProg(FlightRepository.RADIUS_DEG)
        binding.tvRadiusValue.text  = "${FlightRepository.radiusMiles} mi"
        binding.seekRadius.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                FlightRepository.RADIUS_DEG = progToRadius(p)
                binding.tvRadiusValue.text = "${FlightRepository.radiusMiles} mi"
                addRadiusCircle()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) { lifecycleScope.launch { loadFlights() } }
        })
    }

    private fun radiusToProg(deg: Double) = ((deg - 0.1) / 1.8 * 90).toInt().coerceIn(0, 90)
    private fun progToRadius(p: Int)      = 0.1 + p / 90.0 * 1.8

    // ════════════════════════════════════════════════════════════════════
    // MISC
    // ════════════════════════════════════════════════════════════════════

    private fun setupClickListeners() {
        binding.btnRefresh.setOnClickListener {
            it.animate().rotation(it.rotation + 360f).setDuration(500).start()
            lifecycleScope.launch { loadFlights(); loadWeather() }
        }
    }

    private fun scheduleBackgroundMonitor() {
        val req = PeriodicWorkRequestBuilder<FlightMonitorWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            FlightMonitorWorker.WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, req
        )
    }

    private fun requestPermissions() {
        val missing = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.POST_NOTIFICATIONS)
            .filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 1)
    }

    override fun onResume()  { super.onResume(); binding.map.onResume()  }
    override fun onPause()   { super.onPause();  binding.map.onPause()   }
    override fun onDestroy() {
        super.onDestroy()
        if (::pulseAnimator.isInitialized)    pulseAnimator.cancel()
        if (::livePulseAnimator.isInitialized) livePulseAnimator.cancel()
    }
}
