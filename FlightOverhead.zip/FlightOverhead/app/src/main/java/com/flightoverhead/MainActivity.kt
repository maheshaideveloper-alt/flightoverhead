package com.flightoverhead

import android.Manifest
import android.animation.ValueAnimator
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.work.*
import com.flightoverhead.data.Flight
import com.flightoverhead.data.FlightRepository
import com.flightoverhead.data.WeatherRepository
import com.flightoverhead.databinding.ActivityMainBinding
import com.flightoverhead.service.FlightMonitorWorker
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Overlay
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val homePoint = GeoPoint(FlightRepository.HOME_LAT, FlightRepository.HOME_LON)
    private val flightData = mutableMapOf<String, Flight>()

    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val dateFmt = SimpleDateFormat("MMMM d, yyyy", Locale.US)
    private val dayFmt  = SimpleDateFormat("EEEE", Locale.US)

    private var pulseRadius = 30f
    private lateinit var pulseAnimator: ValueAnimator

    private var radiusOverlay: Overlay? = null
    private var selectedIcao: String? = null
    private lateinit var chipOverlay: FlightChipOverlay

    private val overlayHandler = Handler(Looper.getMainLooper())
    private var overlayView: View? = null

    private val darkTiles = XYTileSource(
        "CartoDarkMatter", 0, 19, 256, ".png",
        arrayOf(
            "https://a.basemaps.cartocdn.com/dark_all/",
            "https://b.basemaps.cartocdn.com/dark_all/",
            "https://c.basemaps.cartocdn.com/dark_all/"
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )

        Configuration.getInstance().userAgentValue = packageName
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupMap()
        setupPulseAnimation()
        setupRadiusSlider()
        setupClickListeners()
        requestPermissions()
        startAutoRefresh()
        startClockTick()
        scheduleBackgroundMonitor()

        binding.tvMapCoords.text =
            "%.4f° N  %.4f° W".format(FlightRepository.HOME_LAT, Math.abs(FlightRepository.HOME_LON))
    }

    // ── News overlay ──────────────────────────────────────────────────────

    private fun showNewsOverlay(flightCount: Int) {
        overlayHandler.removeCallbacksAndMessages(null)
        val root = binding.root as ViewGroup
        if (overlayView == null) {
            val v = LayoutInflater.from(this).inflate(R.layout.overlay_radar, root, false)
            root.addView(v)
            overlayView = v
        }
        val ov = overlayView ?: return
        val now = Date()
        ov.findViewById<TextView>(R.id.tvOverlayDay).text  = dayFmt.format(now).uppercase()
        ov.findViewById<TextView>(R.id.tvOverlayDate).text = dateFmt.format(now)

        ov.alpha = 0f
        ov.visibility = View.VISIBLE
        ov.animate().alpha(1f).setDuration(400).withEndAction {
            overlayHandler.postDelayed({
                ov.animate().alpha(0f).setDuration(500).withEndAction {
                    ov.visibility = View.GONE
                }.start()
            }, 2500)
        }.start()
    }

    // ── Pulse animation ───────────────────────────────────────────────────

    private fun setupPulseAnimation() {
        pulseAnimator = ValueAnimator.ofFloat(16f, 60f).apply {
            duration = 1800; repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.RESTART
            addUpdateListener { pulseRadius = it.animatedValue as Float; binding.map.invalidate() }
            start()
        }
    }

    // ── Map ───────────────────────────────────────────────────────────────

    private fun setupMap() {
        binding.map.apply {
            setTileSource(darkTiles)
            setMultiTouchControls(true)
            controller.setZoom(9.5)
            controller.setCenter(homePoint)
            isTilesScaledToDpi = true
        }
        addRadiusCircle()
        addBlueDotOverlay()
        chipOverlay = FlightChipOverlay()
        binding.map.overlays.add(chipOverlay)
    }

    private fun addBlueDotOverlay() {
        val dotPaint    = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL; color = Color.rgb(66, 133, 244) }
        val ringPaint   = Paint().apply { isAntiAlias = true; style = Paint.Style.STROKE; strokeWidth = 3f; color = Color.WHITE }
        val shadowPaint = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL; color = Color.argb(50, 0, 0, 0) }
        val pulsePaint  = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL }
        binding.map.overlays.add(object : Overlay() {
            override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
                if (shadow) return
                val c = mapView.projection.toPixels(homePoint, null)
                val cx = c.x.toFloat(); val cy = c.y.toFloat()
                val frac = (pulseRadius - 16f) / 44f
                pulsePaint.color = Color.argb(((1f - frac) * 120f).toInt().coerceIn(0, 120), 66, 133, 244)
                canvas.drawCircle(cx, cy, pulseRadius, pulsePaint)
                canvas.drawCircle(cx, cy + 2f, 13f, shadowPaint)
                canvas.drawCircle(cx, cy, 12f, dotPaint)
                canvas.drawCircle(cx, cy, 12f, ringPaint)
            }
        })
    }

    private fun addRadiusCircle() {
        radiusOverlay?.let { binding.map.overlays.remove(it) }
        val rad    = FlightRepository.RADIUS_DEG
        val fill   = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL; color = Color.argb(18, 201, 168, 76) }
        val stroke = Paint().apply { isAntiAlias = true; style = Paint.Style.STROKE; color = Color.argb(90, 201, 168, 76); strokeWidth = 2f }
        val ov = object : Overlay() {
            override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
                if (shadow) return
                val proj = mapView.projection
                val c = proj.toPixels(homePoint, null)
                val e = proj.toPixels(GeoPoint(homePoint.latitude + rad, homePoint.longitude), null)
                val r = Math.abs(c.y - e.y).toFloat()
                canvas.drawCircle(c.x.toFloat(), c.y.toFloat(), r, fill)
                canvas.drawCircle(c.x.toFloat(), c.y.toFloat(), r, stroke)
            }
        }
        binding.map.overlays.add(ov)
        radiusOverlay = ov
        binding.map.invalidate()
    }

    // ── Flight chip overlay ───────────────────────────────────────────────
    //
    // Draws each flight as:
    //   • A small gold plane arrow rotated to heading
    //   • A rounded label chip below it with the callsign
    // Handles taps to select + open detail.

    private inner class FlightChipOverlay : Overlay() {

        private var flights: List<Flight> = emptyList()
        // Stored each frame so tap events can do hit-testing without re-projecting
        private val chipBounds = ArrayList<Pair<RectF, Flight>>(32)

        private val bgPaint   = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val bordPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val txtPaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize  = 26f
            typeface  = Typeface.DEFAULT_BOLD
            color     = Color.parseColor("#E8D5A3")
        }
        private val planePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val planePath  = Path()

        fun setFlights(list: List<Flight>) { flights = list }

        override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
            if (shadow) return
            chipBounds.clear()
            for (flight in flights) {
                val pt = mapView.projection.toPixels(
                    GeoPoint(flight.latitude, flight.longitude), null)
                drawChip(canvas, pt.x.toFloat(), pt.y.toFloat(), flight)
            }
        }

        private fun drawChip(canvas: Canvas, cx: Float, cy: Float, flight: Flight) {
            val selected   = flight.icao24 == selectedIcao
            val goldColor  = if (selected) Color.parseColor("#FFD700") else Color.parseColor("#C9A84C")
            val bgColor    = if (selected) Color.argb(245, 35, 22, 0) else Color.argb(210, 7, 11, 20)
            val borderW    = if (selected) 2.5f else 1.5f

            // ── Plane arrow (rotated to heading) ───────────────────────
            planePaint.color = goldColor
            canvas.save()
            canvas.rotate(flight.heading.toFloat(), cx, cy)
            planePath.reset()
            val ps = 13f   // half-width of plane
            planePath.moveTo(cx,         cy - 30f)            // nose
            planePath.lineTo(cx - ps,    cy - 30f + ps * 1.5f) // left wing tip
            planePath.lineTo(cx,         cy - 30f + ps * 0.9f) // tail notch
            planePath.lineTo(cx + ps,    cy - 30f + ps * 1.5f) // right wing tip
            planePath.close()
            canvas.drawPath(planePath, planePaint)
            canvas.restore()

            // ── Label chip ─────────────────────────────────────────────
            val label = flight.callsignClean
            val tw    = txtPaint.measureText(label)
            val pH = 14f; val pV = 7f
            val chipW = tw + pH * 2
            val chipH = txtPaint.textSize + pV * 2

            val left = cx - chipW / 2f
            val top  = cy + 12f
            val rect = RectF(left, top, left + chipW, top + chipH)

            bgPaint.color        = bgColor
            bordPaint.color      = goldColor
            bordPaint.strokeWidth = borderW

            canvas.drawRoundRect(rect, 8f, 8f, bgPaint)
            canvas.drawRoundRect(rect, 8f, 8f, bordPaint)
            canvas.drawText(label, left + pH, top + pV + txtPaint.textSize * 0.85f, txtPaint)

            // Combined hit area: arrow + chip
            chipBounds.add(Pair(RectF(left, cy - 44f, left + chipW, top + chipH), flight))
        }

        override fun onSingleTapConfirmed(e: MotionEvent, mapView: MapView): Boolean {
            val x = e.x; val y = e.y
            // Iterate in reverse so the topmost-drawn chip wins on overlap
            for (i in chipBounds.indices.reversed()) {
                val (rect, flight) = chipBounds[i]
                if (rect.contains(x, y)) {
                    selectFlight(flight.icao24)
                    openFlightDetail(flight)
                    return true
                }
            }
            return false
        }
    }

    // ── Selection ─────────────────────────────────────────────────────────

    private fun selectFlight(icao24: String) {
        selectedIcao = icao24
        binding.map.invalidate()
    }

    private fun clearSelection() {
        selectedIcao = null
        binding.map.invalidate()
    }

    // ── Flight detail ─────────────────────────────────────────────────────

    private fun openFlightDetail(flight: Flight) {
        val intent = android.content.Intent(this, FlightDetailActivity::class.java).apply {
            putExtra(FlightDetailActivity.EXTRA_ICAO24,        flight.icao24)
            putExtra(FlightDetailActivity.EXTRA_CALLSIGN,      flight.callsignClean)
            putExtra(FlightDetailActivity.EXTRA_COUNTRY,       flight.originCountry)
            putExtra(FlightDetailActivity.EXTRA_ALTITUDE,      flight.altitudeFt)
            putExtra(FlightDetailActivity.EXTRA_SPEED,         flight.speedKnots)
            putExtra(FlightDetailActivity.EXTRA_HEADING,       flight.heading.toInt())
            putExtra(FlightDetailActivity.EXTRA_VERTICAL_RATE, flight.verticalRate)
            putExtra(FlightDetailActivity.EXTRA_CLIMB_DESCR,   flight.climbDescr)
            putExtra(FlightDetailActivity.EXTRA_SQUAWK,        flight.squawk ?: "N/A")
            putExtra(FlightDetailActivity.EXTRA_LAT,           flight.latitude)
            putExtra(FlightDetailActivity.EXTRA_LON,           flight.longitude)
        }
        startActivity(intent)
        @Suppress("DEPRECATION")
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    // ── Radius slider ─────────────────────────────────────────────────────

    private fun setupRadiusSlider() {
        binding.seekRadius.progress = radiusToProg(FlightRepository.RADIUS_DEG)
        binding.tvRadiusValue.text  = "${FlightRepository.radiusMiles} mi"
        binding.seekRadius.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                FlightRepository.RADIUS_DEG = progToRadius(p)
                binding.tvRadiusValue.text = "${FlightRepository.radiusMiles} mi"
                addRadiusCircle()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {
                lifecycleScope.launch { loadFlights() }
            }
        })
    }

    private fun radiusToProg(deg: Double) = ((deg - 0.1) / 1.8 * 90).toInt().coerceIn(0, 90)
    private fun progToRadius(p: Int)      = 0.1 + p / 90.0 * 1.8

    // ── Refresh loops ─────────────────────────────────────────────────────

    private fun startAutoRefresh() {
        lifecycleScope.launch {
            while (isActive) {
                loadFlights()
                loadWeather()
                delay(60_000L)
            }
        }
    }

    private fun startClockTick() {
        lifecycleScope.launch {
            while (isActive) {
                val now = Date()
                binding.tvMapTime.text = timeFmt.format(now)
                binding.tvMapDay.text  = dayFmt.format(now).uppercase()
                binding.tvMapDate.text = dateFmt.format(now)
                delay(1_000)
            }
        }
    }

    private suspend fun loadFlights() {
        showLoading(true)
        try {
            val flights = FlightRepository.getFlightsOverhead().sortedByDescending { it.altitudeFt }
            flightData.clear()
            flights.forEach { flightData[it.icao24] = it }
            clearSelection()
            chipOverlay.setFlights(flights)
            binding.map.invalidate()
            binding.tvFlightCount.text = "${flights.size} flights overhead"
            showNewsOverlay(flights.size)
        } catch (e: retrofit2.HttpException) {
            binding.tvFlightCount.text = when (e.code()) {
                429  -> "Rate limited — retrying in 5 min"
                401  -> "API auth error (${e.code()})"
                503  -> "OpenSky offline (${e.code()})"
                else -> "API error ${e.code()}"
            }
        } catch (e: java.net.SocketTimeoutException) {
            binding.tvFlightCount.text = "Timeout — will retry"
        } catch (e: java.net.UnknownHostException) {
            binding.tvFlightCount.text = "No internet connection"
        } catch (e: Exception) {
            binding.tvFlightCount.text = "Error: ${e.javaClass.simpleName}"
        } finally {
            showLoading(false)
        }
    }

    private suspend fun loadWeather() {
        binding.tvWeather.text = WeatherRepository.getWeatherString()
    }

    private fun showLoading(on: Boolean) {
        binding.loadingContainer.visibility =
            if (on && flightData.isEmpty()) View.VISIBLE else View.GONE
    }

    // ── Buttons ───────────────────────────────────────────────────────────

    private fun setupClickListeners() {
        binding.btnRefresh.setOnClickListener {
            it.animate().rotation(it.rotation + 360f).setDuration(500).start()
            lifecycleScope.launch { loadFlights(); loadWeather() }
        }
    }

    // ── Background worker ─────────────────────────────────────────────────

    private fun scheduleBackgroundMonitor() {
        val req = PeriodicWorkRequestBuilder<FlightMonitorWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            FlightMonitorWorker.WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, req
        )
    }

    // ── Permissions ───────────────────────────────────────────────────────

    private fun requestPermissions() {
        val missing = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.POST_NOTIFICATIONS)
            .filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 1)
    }

    override fun onResume()  { super.onResume(); binding.map.onResume()  }
    override fun onPause()   { super.onPause();  binding.map.onPause()   }
    override fun onDestroy() {
        super.onDestroy()
        overlayHandler.removeCallbacksAndMessages(null)
        overlayView = null
        if (::pulseAnimator.isInitialized) pulseAnimator.cancel()
    }
}
