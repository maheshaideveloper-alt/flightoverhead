package com.flightoverhead

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.work.*
import com.flightoverhead.data.Flight
import com.flightoverhead.data.FlightRepository
import com.flightoverhead.databinding.ActivityMainBinding
import com.flightoverhead.service.FlightMonitorWorker
import com.flightoverhead.ui.FlightAdapter
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.util.GeoPoint
import org.osmdroid.util.MapTileIndex
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Overlay
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: FlightAdapter
    private val homePoint = GeoPoint(FlightRepository.HOME_LAT, FlightRepository.HOME_LON)
    private val flightMarkers = mutableMapOf<String, Marker>()
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    // ── Dark CartoDB tile source ────────────────────────────────────────
    private val darkTileSource = XYTileSource(
        "CartoDarkMatter", 0, 19, 256, ".png",
        arrayOf(
            "https://a.basemaps.cartocdn.com/dark_all/",
            "https://b.basemaps.cartocdn.com/dark_all/",
            "https://c.basemaps.cartocdn.com/dark_all/"
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // True full-screen immersive — hides status bar + nav bar, sticky
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )

        Configuration.getInstance().userAgentValue = packageName
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupMap()
        setupClickListeners()
        requestPermissions()
        startAutoRefresh()
        startClockTick()
        scheduleBackgroundMonitor()
    }

    // ── RecyclerView ────────────────────────────────────────────────────

    private fun setupRecyclerView() {
        adapter = FlightAdapter { flight -> openFlightDetail(flight) }
        binding.rvFlights.layoutManager = LinearLayoutManager(this)
        binding.rvFlights.adapter = adapter
        binding.rvFlights.itemAnimator = null // we handle our own fade-in
    }

    // ── Map ─────────────────────────────────────────────────────────────

    private fun setupMap() {
        binding.map.apply {
            setTileSource(darkTileSource)
            setMultiTouchControls(true)
            controller.setZoom(9.5)
            controller.setCenter(homePoint)
            isTilesScaledToDpi = true
        }
        addHomeMarker()
        addRadiusCircle()
        binding.tvMapCoords.text =
            "%.4f° N   %.4f° W".format(FlightRepository.HOME_LAT, Math.abs(FlightRepository.HOME_LON))
    }

    private fun addHomeMarker() {
        Marker(binding.map).apply {
            position = homePoint
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            title = "Home"
            icon = ContextCompat.getDrawable(this@MainActivity, R.drawable.ic_home_gold)
            binding.map.overlays.add(this)
        }
    }

    private fun addRadiusCircle() {
        val radiusDeg = FlightRepository.RADIUS_DEG
        binding.map.overlays.add(object : Overlay() {
            override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
                if (shadow) return
                val fillPaint = Paint().apply {
                    color = Color.argb(20, 201, 168, 76)
                    style = Paint.Style.FILL
                    isAntiAlias = true
                }
                val strokePaint = Paint().apply {
                    color = Color.argb(100, 201, 168, 76)
                    style = Paint.Style.STROKE
                    strokeWidth = 2f
                    isAntiAlias = true
                }
                val proj = mapView.projection
                val center = proj.toPixels(homePoint, null)
                val edge = proj.toPixels(
                    GeoPoint(homePoint.latitude + radiusDeg, homePoint.longitude), null
                )
                val radius = Math.abs(center.y - edge.y).toFloat()
                canvas.drawCircle(center.x.toFloat(), center.y.toFloat(), radius, fillPaint)
                canvas.drawCircle(center.x.toFloat(), center.y.toFloat(), radius, strokePaint)
            }
        })
    }

    // ── Auto-refresh ────────────────────────────────────────────────────

    private fun startAutoRefresh() {
        lifecycleScope.launch {
            while (isActive) {
                loadFlights()
                delay(60_000)
            }
        }
    }

    private fun startClockTick() {
        lifecycleScope.launch {
            while (isActive) {
                binding.tvMapTime.text = timeFmt.format(Date())
                delay(1_000)
            }
        }
    }

    private suspend fun loadFlights() {
        showLoading(true)
        try {
            val flights = FlightRepository.getFlightsOverhead()
                .sortedByDescending { it.altitudeFt }
            updateList(flights)
            updateMap(flights)
            binding.tvFlightCount.text = "${flights.size} flights overhead"
            binding.tvLastUpdated.text = "LIVE  ·  Updated ${timeFmt.format(Date())}"
        } catch (e: Exception) {
            binding.tvLastUpdated.text = "Error: ${e.message?.take(40)}"
        } finally {
            showLoading(false)
        }
    }

    private fun showLoading(loading: Boolean) {
        if (loading && adapter.currentList.isEmpty()) {
            binding.loadingContainer.visibility = View.VISIBLE
            binding.rvFlights.visibility = View.GONE
            binding.emptyState.visibility = View.GONE
        } else {
            binding.loadingContainer.visibility = View.GONE
        }
    }

    private fun updateList(flights: List<Flight>) {
        if (flights.isEmpty()) {
            binding.emptyState.visibility = View.VISIBLE
            binding.rvFlights.visibility = View.GONE
        } else {
            binding.emptyState.visibility = View.GONE
            binding.rvFlights.visibility = View.VISIBLE
        }
        adapter.submitList(flights)
    }

    private fun updateMap(flights: List<Flight>) {
        // Remove stale markers
        val currentIcao = flights.map { it.icao24 }.toSet()
        flightMarkers.keys.filter { it !in currentIcao }.forEach { icao ->
            binding.map.overlays.remove(flightMarkers[icao])
            flightMarkers.remove(icao)
        }
        // Add / update
        for (flight in flights) {
            val pos = GeoPoint(flight.latitude, flight.longitude)
            val existing = flightMarkers[flight.icao24]
            if (existing != null) {
                existing.position = pos
                existing.title   = flight.callsignClean
                existing.snippet = "${"%,d".format(flight.altitudeFt)} ft  ·  ${flight.speedKnots} kts  ·  ${flight.climbDescr}"
                existing.rotation = flight.heading.toFloat()
            } else {
                val marker = Marker(binding.map).apply {
                    position = pos
                    title    = flight.callsignClean
                    snippet  = "${"%,d".format(flight.altitudeFt)} ft  ·  ${flight.speedKnots} kts  ·  ${flight.climbDescr}"
                    icon     = ContextCompat.getDrawable(this@MainActivity, R.drawable.ic_plane_gold)
                    rotation = flight.heading.toFloat()
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                    setOnMarkerClickListener { _, _ -> openFlightDetail(flight); true }
                }
                binding.map.overlays.add(marker)
                flightMarkers[flight.icao24] = marker
            }
        }
        binding.map.invalidate()
    }

    // ── Navigation ───────────────────────────────────────────────────────

    private fun openFlightDetail(flight: Flight) {
        val intent = Intent(this, FlightDetailActivity::class.java).apply {
            putExtra(FlightDetailActivity.EXTRA_ICAO24,        flight.icao24)
            putExtra(FlightDetailActivity.EXTRA_CALLSIGN,      flight.callsignClean)
            putExtra(FlightDetailActivity.EXTRA_COUNTRY,       flight.originCountry)
            putExtra(FlightDetailActivity.EXTRA_ALTITUDE,      flight.altitudeFt)
            putExtra(FlightDetailActivity.EXTRA_SPEED,         flight.speedKnots)
            putExtra(FlightDetailActivity.EXTRA_HEADING,       flight.heading.toInt())
            putExtra(FlightDetailActivity.EXTRA_VERTICAL_RATE, flight.verticalRate)
            putExtra(FlightDetailActivity.EXTRA_CLIMB_DESCR,   flight.climbDescr)
            putExtra(FlightDetailActivity.EXTRA_SQUAWK,        flight.squawk ?: "N/A")
            putExtra(FlightDetailActivity.EXTRA_LAT,           flight.latitude)
            putExtra(FlightDetailActivity.EXTRA_LON,           flight.longitude)
        }
        startActivity(intent)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    // ── Click listeners ─────────────────────────────────────────────────

    private fun setupClickListeners() {
        binding.btnRefresh.setOnClickListener {
            it.animate().rotation(it.rotation + 360f).setDuration(500).start()
            lifecycleScope.launch { loadFlights() }
        }
    }

    // ── Background monitor ───────────────────────────────────────────────

    private fun scheduleBackgroundMonitor() {
        val request = PeriodicWorkRequestBuilder<FlightMonitorWorker>(15, TimeUnit.MINUTES)
            .setConstraints(
                Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
            ).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            FlightMonitorWorker.WORK_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }

    // ── Permissions ──────────────────────────────────────────────────────

    private fun requestPermissions() {
        val perms = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.POST_NOTIFICATIONS
        )
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty())
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 1)
    }

    override fun onResume()  { super.onResume(); binding.map.onResume() }
    override fun onPause()   { super.onPause();  binding.map.onPause()  }
}
