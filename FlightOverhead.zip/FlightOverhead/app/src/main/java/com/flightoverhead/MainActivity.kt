package com.flightoverhead

import android.Manifest
import android.animation.ValueAnimator
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import com.flightoverhead.ui.RadarSweepView
import android.view.animation.LinearInterpolator
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.work.*
import com.flightoverhead.data.Flight
import com.flightoverhead.data.FlightRepository
import com.flightoverhead.data.WeatherRepository
import com.flightoverhead.databinding.ActivityMainBinding
import com.flightoverhead.service.FlightMonitorWorker
import com.flightoverhead.ui.FlightAdapter
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Overlay
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: FlightAdapter

    private val homePoint     = GeoPoint(FlightRepository.HOME_LAT, FlightRepository.HOME_LON)
    private val flightMarkers = mutableMapOf<String, Marker>()
    private val flightData    = mutableMapOf<String, Flight>()

    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val dateFmt = SimpleDateFormat("MMMM d, yyyy", Locale.US)
    private val dayFmt  = SimpleDateFormat("EEEE", Locale.US)

    private var pulseRadius = 30f
    private lateinit var pulseAnimator: ValueAnimator

    private var radiusOverlay: Overlay? = null
    private var selectedIcao: String? = null

    private val overlayHandler = Handler(Looper.getMainLooper())
    private var overlayView: View? = null
    private var radarSweepView: RadarSweepView? = null

    private val darkTiles = XYTileSource(
        "CartoDarkMatter", 0, 19, 256, ".png",
        arrayOf(
            "https://a.basemaps.cartocdn.com/dark_all/",
            "https://b.basemaps.cartocdn.com/dark_all/",
            "https://c.basemaps.cartocdn.com/dark_all/"
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )

        Configuration.getInstance().userAgentValue = packageName
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupMap()
        setupPulseAnimation()
        setupRadiusSlider()
        setupClickListeners()
        requestPermissions()
        startAutoRefresh()
        startClockTick()
        scheduleBackgroundMonitor()

        // Lat + Lon on same line
        binding.tvMapCoords.text =
            "%.4f° N  %.4f° W".format(FlightRepository.HOME_LAT, Math.abs(FlightRepository.HOME_LON))
    }

    // ── News channel overlay ─────────────────────────────────────────────

    private fun showNewsOverlay(flightCount: Int) {
        overlayHandler.removeCallbacksAndMessages(null)

        // Inflate once
        val root = binding.root as ViewGroup
        if (overlayView == null) {
            val v = LayoutInflater.from(this).inflate(R.layout.overlay_radar, root, false)
            root.addView(v)
            overlayView = v
        }
        val ov = overlayView ?: return

        // Populate date and day
        val now = Date()
        ov.findViewById<TextView>(R.id.tvOverlayDay).text  = dayFmt.format(now).uppercase()
        ov.findViewById<TextView>(R.id.tvOverlayDate).text = dateFmt.format(now)

        // Fade in, hold 2s, fade out
        ov.alpha = 0f
        ov.visibility = View.VISIBLE
        ov.animate().alpha(1f).setDuration(400).withEndAction {
            overlayHandler.postDelayed({
                ov.animate().alpha(0f).setDuration(500).withEndAction {
                    ov.visibility = View.GONE
                }.start()
            }, 2000)
        }.start()
    }

    // ── Pulse animation ──────────────────────────────────────────────────

    private fun setupPulseAnimation() {
        pulseAnimator = ValueAnimator.ofFloat(16f, 60f).apply {
            duration = 1800; repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.RESTART; interpolator = LinearInterpolator()
            addUpdateListener { pulseRadius = it.animatedValue as Float; binding.map.invalidate() }
            start()
        }
    }

    // ── RecyclerView ─────────────────────────────────────────────────────

    private fun setupRecyclerView() {
        adapter = FlightAdapter { flight ->
            // List tap → highlight on map + select in list
            selectFlight(flight.icao24)
            binding.map.controller.animateTo(GeoPoint(flight.latitude, flight.longitude))
        }
        binding.rvFlights.layoutManager = LinearLayoutManager(this)
        binding.rvFlights.adapter = adapter
        binding.rvFlights.itemAnimator = null
    }

    // ── Map ──────────────────────────────────────────────────────────────

    private fun setupMap() {
        binding.map.apply {
            setTileSource(darkTiles)
            setMultiTouchControls(true)
            controller.setZoom(9.5)
            controller.setCenter(homePoint)
            isTilesScaledToDpi = true
        }
        addRadiusCircle()
        addBlueDotOverlay()
    }

    private fun addBlueDotOverlay() {
        val dotPaint    = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL;   color = Color.rgb(66, 133, 244) }
        val ringPaint   = Paint().apply { isAntiAlias = true; style = Paint.Style.STROKE; strokeWidth = 3f; color = Color.WHITE }
        val shadowPaint = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL;   color = Color.argb(50, 0, 0, 0) }
        val pulsePaint  = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL }
        binding.map.overlays.add(object : Overlay() {
            override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
                if (shadow) return
                val c = mapView.projection.toPixels(homePoint, null)
                val cx = c.x.toFloat(); val cy = c.y.toFloat()
                val frac = (pulseRadius - 16f) / 44f
                pulsePaint.color = Color.argb(((1f - frac) * 120f).toInt().coerceIn(0, 120), 66, 133, 244)
                canvas.drawCircle(cx, cy, pulseRadius, pulsePaint)
                canvas.drawCircle(cx, cy + 2f, 13f, shadowPaint)
                canvas.drawCircle(cx, cy, 12f, dotPaint)
                canvas.drawCircle(cx, cy, 12f, ringPaint)
            }
        })
    }

    private fun addRadiusCircle() {
        radiusOverlay?.let { binding.map.overlays.remove(it) }
        val rad    = FlightRepository.RADIUS_DEG
        val fill   = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL;   color = Color.argb(18, 201, 168, 76) }
        val stroke = Paint().apply { isAntiAlias = true; style = Paint.Style.STROKE; color = Color.argb(90, 201, 168, 76); strokeWidth = 2f }
        val ov = object : Overlay() {
            override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
                if (shadow) return
                val proj = mapView.projection
                val c = proj.toPixels(homePoint, null)
                val e = proj.toPixels(GeoPoint(homePoint.latitude + rad, homePoint.longitude), null)
                val r = Math.abs(c.y - e.y).toFloat()
                canvas.drawCircle(c.x.toFloat(), c.y.toFloat(), r, fill)
                canvas.drawCircle(c.x.toFloat(), c.y.toFloat(), r, stroke)
            }
        }
        binding.map.overlays.add(ov)
        radiusOverlay = ov
        binding.map.invalidate()
    }

    // ── Selection: highlight red on map + gold in list ────────────────────

    private fun selectFlight(icao24: String) {
        val prev = selectedIcao
        selectedIcao = icao24

        // Swap icon colours
        prev?.let { flightMarkers[it]?.icon = ContextCompat.getDrawable(this, R.drawable.ic_plane_gold) }
        flightMarkers[icao24]?.icon = ContextCompat.getDrawable(this, R.drawable.ic_plane_red)
        binding.map.invalidate()

        // Highlight in list
        adapter.setSelected(icao24)
        val idx = adapter.currentList.indexOfFirst { it.icao24 == icao24 }
        if (idx >= 0) binding.rvFlights.smoothScrollToPosition(idx)
    }

    private fun clearSelection() {
        selectedIcao?.let {
            flightMarkers[it]?.icon = ContextCompat.getDrawable(this, R.drawable.ic_plane_gold)
        }
        selectedIcao = null
        adapter.setSelected(null)
        binding.map.invalidate()
    }

    // ── Radius slider ─────────────────────────────────────────────────────

    private fun setupRadiusSlider() {
        binding.seekRadius.progress = radiusToProg(FlightRepository.RADIUS_DEG)
        binding.tvRadiusValue.text = "${FlightRepository.radiusMiles} mi"
        binding.seekRadius.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                FlightRepository.RADIUS_DEG = progToRadius(p)
                binding.tvRadiusValue.text = "${FlightRepository.radiusMiles} mi"
                addRadiusCircle()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {
                lifecycleScope.launch { loadFlights() }
            }
        })
    }

    private fun radiusToProg(deg: Double) = ((deg - 0.1) / 1.8 * 90).toInt().coerceIn(0, 90)
    private fun progToRadius(p: Int) = 0.1 + p / 90.0 * 1.8

    // ── Refresh loops ─────────────────────────────────────────────────────

    private fun startAutoRefresh() {
        lifecycleScope.launch {
            while (isActive) {
                loadFlights()
                loadWeather()
                delay(60_000)
            }
        }
    }

    private fun startClockTick() {
        lifecycleScope.launch {
            while (isActive) {
                val now = Date()
                binding.tvMapTime.text = timeFmt.format(now)
                binding.tvMapDate.text = dateFmt.format(now)
                binding.tvMapDay.text  = dayFmt.format(now).uppercase()
                delay(1_000)
            }
        }
    }

    private suspend fun loadFlights() {
        showLoading(true)
        try {
            val flights = FlightRepository.getFlightsOverhead().sortedByDescending { it.altitudeFt }
            flightData.clear()
            flights.forEach { flightData[it.icao24] = it }

            // Clear selection on refresh
            clearSelection()

            updateList(flights)
            updateMap(flights)
            binding.tvFlightCount.text = "${flights.size} flights overhead"

            // Show news overlay on every refresh
            showNewsOverlay(flights.size)

        } catch (e: Exception) {
            binding.tvFlightCount.text = "Error loading flights"
        } finally {
            showLoading(false)
        }
    }

    private suspend fun loadWeather() {
        binding.tvWeather.text = WeatherRepository.getWeatherString()
    }

    private fun showLoading(on: Boolean) {
        if (on && adapter.currentList.isEmpty()) {
            binding.loadingContainer.visibility = View.VISIBLE
            binding.rvFlights.visibility = View.GONE
            binding.emptyState.visibility = View.GONE
        } else {
            binding.loadingContainer.visibility = View.GONE
        }
    }

    private fun updateList(flights: List<Flight>) {
        binding.emptyState.visibility = if (flights.isEmpty()) View.VISIBLE else View.GONE
        binding.rvFlights.visibility  = if (flights.isEmpty()) View.GONE   else View.VISIBLE
        adapter.submitList(flights)
    }

    private fun updateMap(flights: List<Flight>) {
        val current = flights.map { it.icao24 }.toSet()
        flightMarkers.keys.filter { it !in current }.forEach { icao ->
            binding.map.overlays.remove(flightMarkers.remove(icao))
        }
        for (flight in flights) {
            val pos = GeoPoint(flight.latitude, flight.longitude)
            val existing = flightMarkers[flight.icao24]
            if (existing != null) {
                existing.position = pos
                existing.rotation = flight.heading.toFloat()
                // Re-apply correct icon after list refresh
                existing.icon = ContextCompat.getDrawable(this,
                    if (flight.icao24 == selectedIcao) R.drawable.ic_plane_red else R.drawable.ic_plane_gold)
            } else {
                val marker = Marker(binding.map).apply {
                    position   = pos
                    icon       = ContextCompat.getDrawable(this@MainActivity, R.drawable.ic_plane_gold)
                    rotation   = flight.heading.toFloat()
                    title      = flight.callsignClean
                    infoWindow = null
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                    setOnMarkerClickListener { _, _ ->
                        selectFlight(flight.icao24)
                        binding.map.controller.animateTo(pos)
                        true
                    }
                }
                binding.map.overlays.add(marker)
                flightMarkers[flight.icao24] = marker
            }
        }
        binding.map.invalidate()
    }

    // ── Buttons ───────────────────────────────────────────────────────────

    private fun setupClickListeners() {
        binding.btnRefresh.setOnClickListener {
            it.animate().rotation(it.rotation + 360f).setDuration(500).start()
            lifecycleScope.launch { loadFlights(); loadWeather() }
        }
    }

    // ── Background worker ─────────────────────────────────────────────────

    private fun scheduleBackgroundMonitor() {
        val req = PeriodicWorkRequestBuilder<FlightMonitorWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            FlightMonitorWorker.WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, req
        )
    }

    // ── Permissions ───────────────────────────────────────────────────────

    private fun requestPermissions() {
        val missing = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.POST_NOTIFICATIONS)
            .filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 1)
    }

    override fun onResume()  { super.onResume(); binding.map.onResume() }
    override fun onPause()   { super.onPause();  binding.map.onPause()  }
    override fun onDestroy() {
        super.onDestroy()
        overlayHandler.removeCallbacksAndMessages(null)
        if (::pulseAnimator.isInitialized) pulseAnimator.cancel()
    }
}
