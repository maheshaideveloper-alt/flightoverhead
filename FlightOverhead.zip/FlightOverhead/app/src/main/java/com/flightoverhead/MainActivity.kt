package com.flightoverhead

import android.Manifest
import android.animation.ValueAnimator
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.work.*
import com.flightoverhead.data.Flight
import com.flightoverhead.data.FlightRepository
import com.flightoverhead.data.WeatherRepository
import com.flightoverhead.databinding.ActivityMainBinding
import com.flightoverhead.service.FlightMonitorWorker
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Overlay
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val homePoint = GeoPoint(FlightRepository.HOME_LAT, FlightRepository.HOME_LON)
    private val flightData = mutableMapOf<String, Flight>()

    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val dateFmt = SimpleDateFormat("MMMM d, yyyy", Locale.US)
    private val dayFmt  = SimpleDateFormat("EEEE", Locale.US)

    private var pulseRadius = 30f
    private lateinit var pulseAnimator: ValueAnimator

    private var radiusOverlay: Overlay? = null
    private var selectedIcao: String? = null
    private lateinit var chipOverlay: FlightChipOverlay

    // Liquid glass accent colours
    private val colorCyan    = Color.parseColor("#00D4FF")
    private val colorMagenta = Color.parseColor("#FF2D78")

    private val darkTiles = XYTileSource(
        "CartoDarkMatter", 0, 19, 256, ".png",
        arrayOf(
            "https://a.basemaps.cartocdn.com/dark_all/",
            "https://b.basemaps.cartocdn.com/dark_all/",
            "https://c.basemaps.cartocdn.com/dark_all/"
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )

        Configuration.getInstance().userAgentValue = packageName
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupMap()
        setupPulseAnimation()
        setupRadiusSlider()
        setupClickListeners()
        requestPermissions()
        startAutoRefresh()
        startClockTick()
        scheduleBackgroundMonitor()

        binding.tvMapCoords.text =
            "%.4f°N\n%.4f°W".format(FlightRepository.HOME_LAT, Math.abs(FlightRepository.HOME_LON))
    }

    // ── Pulse animation ───────────────────────────────────────────────────

    private fun setupPulseAnimation() {
        pulseAnimator = ValueAnimator.ofFloat(16f, 64f).apply {
            duration = 2000; repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.RESTART
            addUpdateListener { pulseRadius = it.animatedValue as Float; binding.map.invalidate() }
            start()
        }
    }

    // ── Map ───────────────────────────────────────────────────────────────

    private fun setupMap() {
        binding.map.apply {
            setTileSource(darkTiles)
            setMultiTouchControls(true)
            controller.setZoom(9.5)
            controller.setCenter(homePoint)
            isTilesScaledToDpi = true
        }
        addRadiusCircle()
        addHomeDotOverlay()
        chipOverlay = FlightChipOverlay()
        binding.map.overlays.add(chipOverlay)
    }

    private fun addHomeDotOverlay() {
        // Outer pulse ring (cyan, matches liquid glass theme)
        val pulsePaint = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL }
        // Inner dot (white core, cyan ring)
        val dotPaint   = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL; color = Color.WHITE }
        val ringPaint  = Paint().apply { isAntiAlias = true; style = Paint.Style.STROKE; strokeWidth = 2.5f; color = colorCyan }
        val shadowPaint= Paint().apply { isAntiAlias = true; style = Paint.Style.FILL; color = Color.argb(60, 0, 0, 0) }

        binding.map.overlays.add(object : Overlay() {
            override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
                if (shadow) return
                val c = mapView.projection.toPixels(homePoint, null)
                val cx = c.x.toFloat(); val cy = c.y.toFloat()
                val frac = (pulseRadius - 16f) / 48f
                // Cyan pulse ring
                pulsePaint.color = Color.argb(((1f - frac) * 90f).toInt().coerceIn(0, 90), 0, 212, 255)
                canvas.drawCircle(cx, cy, pulseRadius, pulsePaint)
                // Dot shadow
                canvas.drawCircle(cx, cy + 2f, 11f, shadowPaint)
                // White core dot
                canvas.drawCircle(cx, cy, 9f, dotPaint)
                // Cyan ring
                canvas.drawCircle(cx, cy, 9f, ringPaint)
            }
        })
    }

    private fun addRadiusCircle() {
        radiusOverlay?.let { binding.map.overlays.remove(it) }
        val rad    = FlightRepository.RADIUS_DEG
        // Liquid glass: cyan tint for the radius zone
        val fill   = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL;   color = Color.argb(12, 0, 212, 255) }
        val stroke = Paint().apply { isAntiAlias = true; style = Paint.Style.STROKE; color = Color.argb(70, 0, 212, 255); strokeWidth = 1.5f }
        val ov = object : Overlay() {
            override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
                if (shadow) return
                val proj = mapView.projection
                val c = proj.toPixels(homePoint, null)
                val e = proj.toPixels(GeoPoint(homePoint.latitude + rad, homePoint.longitude), null)
                val r = Math.abs(c.y - e.y).toFloat()
                canvas.drawCircle(c.x.toFloat(), c.y.toFloat(), r, fill)
                canvas.drawCircle(c.x.toFloat(), c.y.toFloat(), r, stroke)
            }
        }
        binding.map.overlays.add(ov)
        radiusOverlay = ov
        binding.map.invalidate()
    }

    // ── Flight chip overlay ───────────────────────────────────────────────
    //
    // Liquid glass style:
    //   • Plane silhouette drawn in CYAN (#00D4FF) normally
    //   • Glow pass: same shape at 1.4× scale, 15% alpha — drawn first
    //   • Selected: MAGENTA (#FF2D78) with stronger glow
    //   • Label chip: dark glass bg (#B3030B1A), cyan/magenta border, white text
    //
    // Tapping toggles selection. Tapping empty map deselects.

    private inner class FlightChipOverlay : Overlay() {

        private var flights: List<Flight> = emptyList()
        private val hitAreas = ArrayList<Pair<RectF, Flight>>(32)

        // Chip paints
        private val bgPaint    = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val bordPaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val txtPaint   = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            color    = Color.WHITE
        }
        // Plane paints
        private val planePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val glowPaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val planePath  = Path()

        fun setFlights(list: List<Flight>) { flights = list }

        override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
            if (shadow) return
            hitAreas.clear()
            for (flight in flights) {
                val pt = mapView.projection.toPixels(
                    GeoPoint(flight.latitude, flight.longitude), null)
                drawFlight(canvas, pt.x.toFloat(), pt.y.toFloat(), flight)
            }
        }

        private fun drawFlight(canvas: Canvas, cx: Float, cy: Float, flight: Flight) {
            val selected = flight.icao24 == selectedIcao
            val accentColor = if (selected) colorMagenta else colorCyan

            val s = 14f  // scale unit

            // ── Glow pass (drawn behind, larger + very transparent) ─────
            canvas.save()
            canvas.rotate(flight.heading.toFloat(), cx, cy)
            canvas.scale(1.5f, 1.5f, cx, cy)

            glowPaint.color = Color.argb(if (selected) 55 else 30,
                Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
            buildPlanePath(cx, cy, s)
            canvas.drawPath(planePath, glowPaint)
            canvas.restore()

            // ── Normal plane silhouette ────────────────────────────────
            planePaint.color = accentColor
            canvas.save()
            canvas.rotate(flight.heading.toFloat(), cx, cy)
            buildPlanePath(cx, cy, s)
            canvas.drawPath(planePath, planePaint)
            canvas.restore()

            // ── Label chip ─────────────────────────────────────────────
            val label = flight.callsignClean
            val tw    = txtPaint.measureText(label)
            val pH = 12f; val pV = 6f
            val chipW = tw + pH * 2f
            val chipH = txtPaint.textSize + pV * 2f

            val left = cx - chipW / 2f
            val top  = cy + s * 2.2f + 4f
            val rect = RectF(left, top, left + chipW, top + chipH)

            // Glass background
            bgPaint.color = Color.argb(192, 3, 11, 26)
            canvas.drawRoundRect(rect, 8f, 8f, bgPaint)

            // Neon border
            bordPaint.color       = accentColor
            bordPaint.strokeWidth = if (selected) 2.5f else 1.5f
            bordPaint.alpha       = if (selected) 255 else 180
            canvas.drawRoundRect(rect, 8f, 8f, bordPaint)

            // Text
            canvas.drawText(label, left + pH, top + pV + txtPaint.textSize * 0.85f, txtPaint)

            // Hit area: plane bounds + chip
            hitAreas.add(Pair(
                RectF(cx - s * 2.2f, cy - s * 2.2f, cx + s * 2.2f, top + chipH),
                flight
            ))
        }

        /** Builds the plane silhouette path centred at (cx, cy), nose pointing up (−Y). */
        private fun buildPlanePath(cx: Float, cy: Float, s: Float) {
            planePath.reset()

            // Fuselage
            planePath.moveTo(cx,              cy - s * 2.0f)
            planePath.lineTo(cx + s * 0.22f,  cy - s * 0.8f)
            planePath.lineTo(cx + s * 0.22f,  cy + s * 1.3f)
            planePath.lineTo(cx,              cy + s * 1.6f)
            planePath.lineTo(cx - s * 0.22f,  cy + s * 1.3f)
            planePath.lineTo(cx - s * 0.22f,  cy - s * 0.8f)
            planePath.close()

            // Main wings
            planePath.moveTo(cx,              cy - s * 0.4f)
            planePath.lineTo(cx + s * 2.0f,   cy + s * 0.7f)
            planePath.lineTo(cx + s * 1.6f,   cy + s * 1.0f)
            planePath.lineTo(cx + s * 0.2f,   cy + s * 0.5f)
            planePath.lineTo(cx - s * 0.2f,   cy + s * 0.5f)
            planePath.lineTo(cx - s * 1.6f,   cy + s * 1.0f)
            planePath.lineTo(cx - s * 2.0f,   cy + s * 0.7f)
            planePath.close()

            // Tail stabilisers
            planePath.moveTo(cx,              cy + s * 1.0f)
            planePath.lineTo(cx + s * 0.9f,   cy + s * 1.5f)
            planePath.lineTo(cx + s * 0.2f,   cy + s * 1.6f)
            planePath.lineTo(cx - s * 0.2f,   cy + s * 1.6f)
            planePath.lineTo(cx - s * 0.9f,   cy + s * 1.5f)
            planePath.close()
        }

        override fun onSingleTapConfirmed(e: MotionEvent, mapView: MapView): Boolean {
            val x = e.x; val y = e.y
            for (i in hitAreas.indices.reversed()) {
                val (rect, flight) = hitAreas[i]
                if (rect.contains(x, y)) {
                    selectedIcao = if (selectedIcao == flight.icao24) null else flight.icao24
                    mapView.invalidate()
                    return true
                }
            }
            selectedIcao = null
            mapView.invalidate()
            return false
        }
    }

    // ── Radius slider ─────────────────────────────────────────────────────

    private fun setupRadiusSlider() {
        binding.seekRadius.progress = radiusToProg(FlightRepository.RADIUS_DEG)
        binding.tvRadiusValue.text  = "${FlightRepository.radiusMiles} mi"
        binding.seekRadius.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                FlightRepository.RADIUS_DEG = progToRadius(p)
                binding.tvRadiusValue.text = "${FlightRepository.radiusMiles} mi"
                addRadiusCircle()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {
                lifecycleScope.launch { loadFlights() }
            }
        })
    }

    private fun radiusToProg(deg: Double) = ((deg - 0.1) / 1.8 * 90).toInt().coerceIn(0, 90)
    private fun progToRadius(p: Int)      = 0.1 + p / 90.0 * 1.8

    // ── Refresh loops ─────────────────────────────────────────────────────

    private fun startAutoRefresh() {
        lifecycleScope.launch {
            while (isActive) {
                loadFlights()
                loadWeather()
                delay(60_000L)
            }
        }
    }

    private fun startClockTick() {
        lifecycleScope.launch {
            while (isActive) {
                val now = Date()
                binding.tvMapTime.text = timeFmt.format(now)
                binding.tvMapDay.text  = dayFmt.format(now).uppercase()
                binding.tvMapDate.text = dateFmt.format(now)
                delay(1_000)
            }
        }
    }

    private suspend fun loadFlights() {
        showLoading(true)
        try {
            val flights = FlightRepository.getFlightsOverhead().sortedByDescending { it.altitudeFt }
            flightData.clear()
            flights.forEach { flightData[it.icao24] = it }
            selectedIcao = null
            chipOverlay.setFlights(flights)
            binding.map.invalidate()
            binding.tvFlightCount.text = "${flights.size} flights"
        } catch (e: retrofit2.HttpException) {
            binding.tvFlightCount.text = when (e.code()) {
                429  -> "rate limited"
                401  -> "auth error"
                503  -> "API offline"
                else -> "error ${e.code()}"
            }
        } catch (e: java.net.SocketTimeoutException) {
            binding.tvFlightCount.text = "timeout"
        } catch (e: java.net.UnknownHostException) {
            binding.tvFlightCount.text = "no internet"
        } catch (e: Exception) {
            binding.tvFlightCount.text = "error"
        } finally {
            showLoading(false)
        }
    }

    private suspend fun loadWeather() {
        binding.tvWeather.text = WeatherRepository.getWeatherString()
    }

    private fun showLoading(on: Boolean) {
        binding.loadingContainer.visibility =
            if (on && flightData.isEmpty()) View.VISIBLE else View.GONE
    }

    // ── Buttons ───────────────────────────────────────────────────────────

    private fun setupClickListeners() {
        binding.btnRefresh.setOnClickListener {
            it.animate().rotation(it.rotation + 360f).setDuration(500).start()
            lifecycleScope.launch { loadFlights(); loadWeather() }
        }
    }

    // ── Background worker ─────────────────────────────────────────────────

    private fun scheduleBackgroundMonitor() {
        val req = PeriodicWorkRequestBuilder<FlightMonitorWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            FlightMonitorWorker.WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, req
        )
    }

    // ── Permissions ───────────────────────────────────────────────────────

    private fun requestPermissions() {
        val missing = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.POST_NOTIFICATIONS)
            .filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 1)
    }

    override fun onResume()  { super.onResume(); binding.map.onResume()  }
    override fun onPause()   { super.onPause();  binding.map.onPause()   }
    override fun onDestroy() {
        super.onDestroy()
        if (::pulseAnimator.isInitialized) pulseAnimator.cancel()
    }
}
